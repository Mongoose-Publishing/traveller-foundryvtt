# Effect Icons

Based on icons from game-icons.net. CC-BY 3.0

destroyed.svg - https://game-icons.net/1x1/lorc/spiky-explosion.html
encumbered.svg - https://game-icons.net/1x1/delapouite/weight.html
firstaid.avg - https://game-icons.net/1x1/delapouite/first-aid-kit.html
injured.svg - https://game-icons.net/1x1/lorc/broken-heart.html
surgery.svg - https://game-icons.net/1x1/lorc/syringe.html
vaccsuit.svg - https://game-icons.net/1x1/lorc/space-suit.html
