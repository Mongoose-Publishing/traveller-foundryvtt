import { MgT2Item } from "../documents/item.mjs";
import { Tools } from "../helpers/chat/tools.mjs";
import {MGT2} from "../helpers/config.mjs";
import {MgT2DamageDialog} from "../helpers/damage-dialog.mjs";
import {getTraitValue, hasTrait, isNonZero, isNumber, skillLabel} from "../helpers/dice-rolls.mjs";
import {MgT2SpacecraftDamageDialog} from "../helpers/spacecraft-damage-dialog.mjs";
import {setSpacecraftCriticalLevel} from "../helpers/spacecraft/criticals.mjs";
import {MgT2VehicleDamageDialog} from "../helpers/vehicle-damage-dialog.mjs";
const  { renderTemplate } = foundry.applications.handlebars;

/**
 * Extend the base Actor document by defining a custom roll data structure which is ideal for the Simple system.
 * @extends {Actor}
 */
export class MgT2Actor extends Actor {

  /** @override */
  prepareData() {
    // Prepare data for the actor. Calling the super version of this executes
    // the following, in order: data reset (to clear active effects),
    // prepareBaseData(), prepareEmbeddedDocuments() (including active effects),
    // prepareDerivedData().
    super.prepareData();
  }

    /** @override */
    prepareBaseData() {
        // Must call super to clear overrides, statuses, and _completedActiveEffectPhases
        // before each prepare cycle (required for Foundry v14 ActiveEffect application).
        super.prepareBaseData();

        // Foundry v14: for template.json-based systems (non-TypeDataModel), characteristic values
        // are not reset from source between prepareData() calls. Reset them individually to prevent
        // ActiveEffect modifications from accumulating across repeated prepareData() cycles.
        // NOTE: avoid mergeObject on this.system (Proxy) — it causes duplicate ownKeys trap entries.
        const srcChars = this._source?.system?.characteristics;
        if (srcChars && this.system.characteristics) {
            for (const char of Object.keys(srcChars)) {
                if (this.system.characteristics[char] !== undefined) {
                    this.system.characteristics[char].value = srcChars[char].value;
                    // Reset AE-modified fields so they don't accumulate across prepareData cycles
                    this.system.characteristics[char].augment = srcChars[char].augment ?? 0;
                    this.system.characteristics[char].augdm = 0;
                    this.system.characteristics[char].min = srcChars[char].min ?? 0;
                }
            }
        }

        // Data modifications in this step occur before processing embedded
        // documents or derived data.
        if (this.system.hits && this.type !== "traveller") {
            let hits = this.system.hits;
            if (!hits) {
                this.system.hits = {
                    damage: 0,
                    value: 21,
                    max: 21
                }
                hits = this.system.hits;
            }
            if (hits.value !== (hits.max - hits.damage)) {
                hits.value = parseInt(hits.max) - parseInt(hits.damage);
            }
            hits.tmpDamage = Math.min(hits.tmpDamage, hits.damage);
        }
        switch (this.type) {
            case "vehicle":
                this._prepareVehicleBaseData(this);
                break;
        }
    }

    async _preUpdate(changes, options, user) {
        if (this.type === "spacecraft") {
            if (changes?.system?.spacecraft?.dtons) {
                let dtons = parseInt(changes.system.spacecraft.dtons);
                if (dtons < 1) {
                    dtons = changes.system.spacecraft.dtons = 1;
                }
                if (!changes.system.modifiers) {
                    changes.system.spacecraft.modifiers = {
                        baseEvadeDM: 0,
                        signature: 0,
                        stealth: 0
                    };
                }
                let sizeDM = Math.min(6, parseInt(dtons / 1000));
                //changes.system.spacecraft.combat.sizeDM = sizeDM;
                //await this.setFlag("mgt2e", "sizeDM", sizeDM);

                if (dtons < 100) {
                    changes.system.spacecraft.skill = "pilot.smallCraft";
                } else if (dtons <= 5000) {
                    changes.system.spacecraft.skill = "pilot.spacecraft";
                } else {
                    changes.system.spacecraft.skill = "pilot.capitalShips";
                }
            }
        }
    }

    /**
     * Called when an attribute on a token is directly modified by the user.
     * Used for updating damage on the actor.
     */
    modifyTokenAttribute(attribute, value, isDelta, isBar) {
        if (this.type === "traveller" || this.system.damage) {
            let damage = parseInt(value);
            if (isDelta && damage < 0) {
                damage = Math.abs(damage);
                console.log("Applying " + damage);
                damage = Tools.applyDamageToCha(damage, this.system, "END");
                damage = Tools.applyDamageToCha(damage, this.system, "STR");
                damage = Tools.applyDamageToCha(damage, this.system, "DEX");
            }
            return this.update({"system.damage": this.system.damage});
        } else if (this.system.hits) {
            let hits = this.system.hits;
            if (isDelta) {
                hits.damage -= parseInt(value);
            } else {
                hits.damage = hits.max - parseInt(value);
            }
            hits.value = hits.max - hits.damage;
            return this.update({"system.hits": this.system.hits });
        }
    }

    /**
     * @override
     * Augment the basic actor data with additional dynamic data. Typically,
     * you'll want to handle most of your calculated/derived data in this step.
     * Data calculated in this step should generally not exist in template.json
     * (such as ability modifiers rather than ability scores) and should be
     * available both inside and outside of character sheets (such as if an actor
     * is queried and has a roll executed directly from it).
     */
    prepareDerivedData() {
        const actorData = this;

        // Make separate methods for each Actor type (traveller, npc, etc.) to keep
        // things organized.
        this._prepareTravellerData(actorData);
        this._prepareNpcData(actorData);
        this._prepareCreatureData(actorData);
        this._prepareSpacecraftData(actorData);
        this._prepareVehicleData(actorData);
    }


  /**
   * Get the characteristic modifier for a given value.
   * Values are normally 0+, with 6-8 providing a +0 modifier.
   */
  getModifier(value) {
      if (value < 1) {
          return -3;
      } else if (value < 3) {
          return -2;
      } else {
          return parseInt(value / 3) - 2;
      }
  }

    _prepareEncumbrance(actorData) {
        if (!actorData.system) {
            return;
        }
        let sys = actorData.system;
        let heavyLoad = 0;

        if (sys.characteristics) {
            const ch = sys.characteristics;
            if (ch['STR']) {
                heavyLoad += parseInt(ch['STR'].current);
            }
            if (ch['END']) {
                heavyLoad += parseInt(ch['END'].current);
            }
        }
        if (sys.skills) {
            if (sys.skills['athletics'] && sys.skills['athletics'].trained) {
                const ath = sys.skills['athletics'];
                if (ath.specialities && ath.specialities.strength) {
                    heavyLoad += parseInt(ath.specialities.strength.value);
                }
                if (ath.specialities && ath.specialities.endurance) {
                    heavyLoad += parseInt(ath.specialities.endurance.value);
                }
            }
        }
        if (sys.modifiers.encumbrance.multiplierBonus) {
            let mult = 1 + parseFloat(sys.modifiers.encumbrance.multiplierBonus);
            heavyLoad *= mult;
        }
        sys.heavyLoad = heavyLoad;
        sys.maxLoad = heavyLoad * 2;
    }

    _prepareInitiative(actorData) {
        if (!actorData.system) {
            return;
        }
        let dex = parseInt(actorData.system.characteristics["DEX"]?.dm);
        let int = parseInt(actorData.system.characteristics["INT"]?.dm);

        if (isNaN(dex)) dex = 0;
        if (isNaN(int)) int = 0;

        if (typeof actorData.system.initiative === "number") {
            actorData.system.initiative = {
                base: 0,
                value: 0
            }
        }
        actorData.system.initiative.base = Math.max(int, dex);
        actorData.system.initiative.value = actorData.system.initiative.base;
        if (actorData.system.modifiers.initiative?.custom) {
            actorData.system.initiative.value += Number(actorData.system.modifiers.initiative.custom);
        }
        if (actorData.system.modifiers.initiative?.effect) {
            actorData.system.initiative.value += Number(actorData.system.modifiers.initiative.effect);
        }

        // Also calculate Dodge ability.
        let dodge = Math.max(dex, 0);
        if (actorData.system.skills["athletics"] && actorData.system.skills["athletics"].specialities) {
            let dodgeSkill = parseInt(actorData.system.skills["athletics"].specialities["dexterity"].value);
            if (dodgeSkill > 0) {
                dodge += dodgeSkill;
            }
        }
        actorData.system.dodge = dodge;
    }

    _countSkillLevels(skillData) {
      let total = 0;
      for (var s in skillData) {
          if (skillData[s].trained) {
              total += (skillData[s].value>0)?parseInt(skillData[s].value):0;
              if (skillData[s].specialities) {
                  for (var sp in skillData[s].specialities) {
                      total += (skillData[s].specialities[sp].value>0)?parseInt(skillData[s].specialities[sp].value):0;
                  }
              }
          }
      }
      return total;
    }

    // Pre-effects
    _prepareVehicleBaseData(actorData) {
        console.log("_prepareVehicleBaseData:");
        console.log(actorData.system.vehicle.speedBand);

        const s = Math.ceil(Math.max(1, parseInt(actorData.system.hits.value) / 10));
        actorData.system.structure.value = s;

        let vehicleType = actorData.system.vehicle.type;
        if (!CONFIG.MGT2.VEHICLES.TYPE[vehicleType]) {
            vehicleType = actorData.system.vehicle.type = "groundVehicle";
        }
        const typeData = CONFIG.MGT2.VEHICLES.TYPE[vehicleType];
        if (actorData.system.vehicle.tl < typeData.tl) {
            actorData.system.vehicle.tl = typeData.tl;
        }
        const techLevel = parseInt(actorData.system.vehicle.tl);

        // Hits
        const spaces = parseInt(actorData.system.vehicle.spaces) || 0;
        const hull = Math.max(1, parseInt(typeData.hull * spaces));
        if (hull !== parseInt(actorData.system.hits.hull)) {
            const HITS = actorData.system.hits;
            HITS.hull = hull;
            HITS.structure = Math.ceil(HITS.hull / 10);
            HITS.max = 10;
            HITS.value = HITS.max - HITS.damage;
        }

        // Performance
        let speedBand = 0;
        let range = 0;

        for (let i=0; i < typeData.performance.length; i++) {
            if (typeData.performance[i].min <= techLevel) {
                const speedName = typeData.performance[i].speed;
                speedBand = CONFIG.MGT2.VEHICLES.SPEED[speedName].band;
                range = typeData.performance[i].range;
            }
        }
        if (actorData.system.vehicle?.customisation?.speedModifications) {
            speedBand += parseInt(actorData.system.vehicle?.customisation?.speedModifications)||0;
        }

        actorData.system.vehicle.speedBand = speedBand;
        actorData.system.vehicle.fuelRange.max = range;

        actorData.system.vehicle.traits = "";
        if (typeData.traits && typeData.traits.length > 0) {
            for (let trait of typeData.traits) {
                actorData.system.vehicle.traits += ","+trait;
            }
        }
        for (let feature of actorData.system.vehicle.features.split(",")) {
            if (!feature || !CONFIG.MGT2.VEHICLES.FEATURES[feature]) {
                continue;
            }
            const fData = CONFIG.MGT2.VEHICLES.FEATURES[feature];
            if (fData.traits && fData.traits.length > 0) {
                for (let trait of fData.traits) {
                    actorData.system.vehicle.traits += "," + trait;
                }
            }
        }
        actorData.system.vehicle.traits = actorData.system.vehicle.traits.replaceAll(/^,/g, "");
    }

    // Prepare derived data for vehicles.
    _prepareVehicleData(actorData) {
        if (!["vehicle"].includes(actorData.type)) return;

        console.log("_prepareVehicleData:");
        // Hull may have been modified by active effects, so re-calculate structure here.
        const HITS = actorData.system.hits;
        HITS.structure = Math.ceil(HITS.hull / 10);

    }

    /**
     * Prepare Character type specific data
     */
    _prepareTravellerData(actor) {
        if (!["traveller", "npc"].includes(actor.type)) return;

        const sys = actor.system;
        if (sys.characteristics.INT && sys.characteristics.EDU) {
            sys.totalSkills = this._countSkillLevels(sys.skills);
            sys.maxSkills = (parseInt(sys.characteristics.INT.value) +
                Number(sys.characteristics.EDU.value)) * 3;
        } else {
            sys.maxSkills = 0;
        }

        // In case someone has replaced the characteristics.
        if (!sys.characteristics.STR || !sys.characteristics.DEX || !sys.characteristics.END) {
            return;
        }

        // Collect augdm bonuses and boon/bane from AEs directly (these fields are not in schema,
        // so Foundry's proxy won't persist field writes from AE application)
        const chaDmBonuses = {};
        const chaBoonMap = {};   // char → "boon" or "bane"
        for (const effect of this.allApplicableEffects()) {
            if (effect.disabled) continue;
            for (const change of effect.changes) {
                const mDm = change.key.match(/^system\.characteristics\.(\w+)\.augdm$/);
                if (mDm) {
                    chaDmBonuses[mDm[1]] = (chaDmBonuses[mDm[1]] ?? 0) + Number(change.value);
                    continue;
                }
                const mBoon = change.key.match(/^system\.characteristics\.(\w+)\.(boon|bane)$/);
                if (mBoon) {
                    chaBoonMap[mBoon[1]] = mBoon[2];
                }
            }
        }

        for (const char in sys.characteristics) {
            let value = sys.characteristics[char].value;
            if (sys.characteristics[char].augment) {
                value += Number(sys.characteristics[char].augment);
            }
            if (sys.characteristics[char].min) {
                value = Math.max(value, Number(sys.characteristics[char].min));
            }
            let dmg = 0;
            if (sys.damage && sys.damage[char]) {
                dmg = sys.damage[char].value;
                if (dmg < 0) {
                    dmg = 0;
                    sys.damage[char].value = dmg;
                }
                if (dmg > value) {
                    dmg = value;
                    sys.damage[char].value = dmg;
                }
                value -= dmg;
            }
            sys.characteristics[char].current = value;
            let dm = this.getModifier(value);
            if (chaDmBonuses[char]) {
                dm += chaDmBonuses[char];
            }
            sys.characteristics[char].dm = dm;
            sys.characteristics[char].boon = chaBoonMap[char] ?? null;
        }

        if (sys.damage && sys.hits) {
            let maxHits = sys.characteristics.STR.value + sys.characteristics.DEX.value +
                sys.characteristics.END.value;
            let totalDmg = sys.damage["STR"].value + sys.damage["DEX"].value + sys.damage["END"].value;
            for (let c in sys.damage) {
                if (sys.damage[c].value >= sys.characteristics[c].value) {
                    sys.damage[c].state = "zero";
                } else if (sys.damage[c].value >= sys.characteristics[c].value / 2) {
                    sys.damage[c].state = "low";
                } else {
                    sys.damage[c].state = "okay";
                }
            }
            if (isNaN(totalDmg)) totalDmg = 0;

            sys.hits.value = Math.max(0, maxHits - totalDmg);
            sys.hits.max = maxHits;
        }
        this._prepareEncumbrance(actor);
        this._prepareInitiative(actor);
    }

    _prepareNpcData(actor) {
        if (actor.type !== 'npc') return;
        const actorData = actor.system;

        if (actorData.damage) {
            // Already done in prepareTraveller
        } else if (actorData.hits && actorData.settings.autoHits) {
            let maxHits = actorData.characteristics.STR?.value +
                actorData.characteristics.DEX?.value +
                actorData.characteristics.END?.value;

            if (isNaN(maxHits)) {
                maxHits = 21;
            }
            actorData.hits.max = maxHits;
            actorData.hits.value = maxHits - actorData.hits.damage;
        }
    }

    _prepareCreatureData(actor) {
        if (actor.type !== 'creature') return;

        const actorData = actor.system;

        if (actorData.hits) {
            if (!actorData.hits.damage) {
                actorData.hits.damage = 0;
            }
            actorData.hits.value = parseInt(actorData.hits.max) - parseInt(actorData.hits.damage);
        }
/*
        actorData.initiative = {
            base: 0,
            value: 0
        }
*/
        // Also calculate Dodge ability.
        let dodge = 0;
        let dodgeSkill = parseInt(actorData.skills["athletics"].specialities["dexterity"].value);
        if (dodgeSkill > 0) {
            dodge += dodgeSkill;
        }
        actorData.dodge = dodge;
    }

    _prepareSpacecraftData(actor) {
        if (actor.type !== "spacecraft") return;
        const actorData = actor.system;

        if (!actorData.spacecraft.combat) {
            actorData.spacecraft.combat = {
                "sizeDM": Math.min(6, parseInt(actorData.spacecraft.dtons / 1000)),
                "evadeThrustUsed": 0,
                "evadeDM": 0,
                "gunnerDM": 0
            }
        } else {
            //actorData.spacecraft.combat.sizeDM = Math.min(6, parseInt(actorData.spacecraft.dtons / 1000));
        }
        if (!actorData.initiative) {
            actorData.initiative = {
                "base": 0,
                "value": 0
            }
        }
        let init = actorData.initiative;
        init.base = parseInt(actorData.spacecraft.mdrive) + parseInt(actorData.spacecraft.rdrive);
        init.value = parseInt(init.base);

        if (this.getFlag("mgt2e","initPilotDM")) {
            init.value += parseInt(this.getFlag("mgt2e", "initPilotDM"));
        }
        if (this.getFlag("mgt2e","initTacticsDM")) {
            init.value += parseInt(this.getFlag("mgt2e", "initTacticsDM"));
        }
    }


    /**
     * Override getRollData() that's supplied to rolls.
     */
    getRollData() {
        const data = super.getRollData();

        // Prepare traveller roll data.
        this._getTravellerRollData(data);

        return data;
    }

  /**
   * Prepare character roll data.
   */
  _getTravellerRollData(data) {
    if (this.type !== 'traveller' && this.type !== 'npc') return;

    if (!data.characteristics) {
        console.log("This Traveller has no characteristics");
        return;
    }

    for (let [k,v] of Object.entries(data.characteristics)) {
        data[k] = v.dm ?? -3;
    }

  }

  hasCreatureTrait(trait) {
    if (this.type === "creature" && this.system.traits) {
      const traits = this.system.traits;
      if (traits.indexOf(trait) > -1) {
        return true;
      }
    }
    return false;
  }

  getCreatureTrait(trait) {
      if (this.type === "creature" && this.system.traits) {
          const traits = this.system.traits;
          if (traits.indexOf(trait) > -1) {
              const regex = new RegExp(`.*\(${trait}[^,$]*\).*`, "g");
              return traits.replace(regex, "$1");
          }
      }
      return null;
  }

  getUntrained() {
      let score = -3;
      if (this.system.skills["jackofalltrades"]) {
          let joat = parseInt(this.system.skills["jackofalltrades"].value);
          if (joat > 0) {
              score += joat;
          }
      }
      return score;
  }

    /**
     * Try and find active owner of this actor. Normally used for handing over damage management to.
     * A user must be active, and have ownership of the actor. Users are searched for in this order:\
     * - Traveller character with a 'player' set to the name of the user
     * - Non-GM user who has permissions specifically set to 3
     * - Non-GM user who has permissions of 3 due to default permissions
     * - The player set by 'Damage Manager' setting
     * - The active GM
     */
  findActorOwner() {
      // First, look for the player mentioned on the character sheet.
      let defaultPlayer = null;
      for (let u of game.users) {
          if (u.active && u.name === this.system.player) {
              if (this.ownership[u._id] !== undefined) {
                  if (this.ownership[u.id] === 3) {
                      return u;
                  }
              } else if (this.ownership["default"] === 3) {
                  return u;
              }
          } else if (!defaultPlayer && u.active && !u.isGM) {
              if (this.ownership["default"] === 3) {
                defaultPlayer = u;
              }
          }
      }
      // Now look for a non-GM with specifically named owner permissions.
      for (let u in this.ownership) {
          if (this.ownership[u] === 3 && game.users.get(u)?.active) {
              if (!game.users.get(u).isGM) {
                  return game.users.get(u);
              }
          }
      }
      // If there is a non-GM with default owner permissions, use them.
      if (defaultPlayer) {
          return defaultPlayer;
      }
      // Finally, just use the GM. If a backup GM has been set to handle damage, then
      // use that user, otherwise use whichever GM is marked as active.
      let gm = game.users.activeGM;
      let damageManager = game.settings.get("mgt2e", "damageManager");
      if (damageManager) {
          let user = game.users.getName(damageManager);
          if (user && user.active && user.isGM) {
              gm = game.users.getName(damageManager);
          }
      }

      return gm;
  }

  findAblatTarget(options) {
      if (options.damageType) {
          for (let i of this.items) {
              if (i.type === "armour" && i.system.armour.ablat === "1" && i.system.status === MgT2Item.EQUIPPED) {
                  if (i.system.armour.otherTypes.indexOf(options.damageType) > -1) {
                      return i;
                  }
              }
          }
      }
      return null;
  }

  async applyAnyAblatDamage(options, ablatItem) {
      // How do we handle ablat?
      if (ablatItem && ablatItem.type === "armour") {
          let otherProt = parseInt(ablatItem.system?.armour?.otherProtection);
          if (!isNaN(otherProt)) {
              ablatItem.update({"system.armour.otherProtection": otherProt - 1});
          }
      } else {
          for (let i of this.items) {
              if (i.type === "armour" && i.system.armour.ablat === "1" && i.system.status === MgT2Item.EQUIPPED) {
                  if (i.system.armour.otherTypes.indexOf(options.damageType) > -1) {
                      let otherProt = parseInt(i.system.armour.otherProtection);
                      if (otherProt > 0) {
                          const yes = await foundry.applications.api.DialogV2.confirm({
                              window: { title: game.i18n.format("MGT2.Dialog.AblateConfirm.Title", { actor: this.name }) },
                              content: `<p>${game.i18n.format("MGT2.Dialog.AblateConfirm.Text", { armour: i.name })}</p>`
                          });
                          if (yes) {
                              i.update({"system.armour.otherProtection": otherProt - 1});
                          }
                      }
                      return;
                  }
              }
          }
      }
  }

  async applyDamageToPerson(damage, options) {
      let armour = 0;
      let armourText = ""
      let radiationDamage = options.radiation ? options.radiation : 0;
      options.armour = 0;

      if (this.permission < 3) {
          console.log("I don't have permission, looking for alternative player");
          let alternativePlayer = this.findActorOwner();
          if (alternativePlayer) {
              console.log(alternativePlayer);
              game.socket.emit("system.mgt2e", {
                  type: "applyDamageToPerson",
                  userId: alternativePlayer.uuid,
                  actorId: this.uuid,
                  damage: damage,
                  damageOptions: options,
                  currentPlayerId: game.users.current.uuid,
              });
              ui.notifications.info(game.i18n.format("MGT2.Info.ActorOwnerFound", {
                  "actor": this.name,
                  "player": alternativePlayer.name
              }));
          } else {
              ui.notifications.error(game.i18n.format("MGT2.Error.NoSuitableOwner", { "actor": this.name }));
          }
          return;
      } else if (game.users.current.isGM) {
          console.log("I am the GM, looking for alternative player");
          let alternativePlayer = this.findActorOwner();
          if (alternativePlayer && alternativePlayer.uuid !== game.users.current.uuid) {
              console.log(alternativePlayer);
              game.socket.emit("system.mgt2e", {
                  type: "applyDamageToPerson",
                  userId: alternativePlayer.uuid,
                  actorId: this.uuid,
                  damage: damage,
                  damageOptions: options,
                  currentPlayerId: game.users.current.uuid,
              });
              ui.notifications.info(game.i18n.format("MGT2.Info.ActorOwnerFound", {
                  "actor": this.name,
                  "player": alternativePlayer.name
              }));
              return;
          }
      }

      // Check for characteristic damage
      let damageType = options.damageType ? options.damageType : "standard";
      if (this.system.characteristics && this.system.characteristics[damageType]) {
          // Damage is to a characteristic. Skip usual armour stuff.
          options.ap = 0;
          options.armour = 0;
          options.finalArmour = 0;
      } else {
          if (this.system.armour && isNonZero(this.system.armour.protection)) {
              armour = parseInt(this.system.armour.protection);
              if (!isNumber(armour)) {
                  armour = 0;
              }
              options.armour = armour;
              armourText = game.i18n.localize("MGT2.Armour.Protection") + " " + armour + " ";
              armour = Math.max(0, armour);
              // Halve protection value if armour is archaic and weapon TL is higher.
              if (parseInt(this.system.armour.archaic) === 1 && options.ranged) {
                  if (parseInt(options.tl) > parseInt(this.system.tl)) {
                      armour = parseInt((armour + 1) / 2);
                      armourText += `(${game.i18n.localize("MGT2.Armour.Archaic")}) `;
                  }
              }
          }
          if (this.system.armour && options.damageType !== "") {
              let armourData = this.system.armour;
              if (armourData.otherTypes && armourData.otherTypes.indexOf(options.damageType) > -1) {
                  let otherProt = armourData.otherProtection ? parseInt(armourData.otherProtection) : 0;
                  if (otherProt !== 0) {
                      armour += otherProt;
                      armourText += `${options.damageType} + ${otherProt} `;
                  }
              }
          }
          // Look for active weapons which provide protection.
          for (let i of this.items) {
              if (i.type === "weapon" && i.system.status === MgT2Item.EQUIPPED) {
                  if (hasTrait(i.system.weapon.traits, "protection")) {
                      let value = getTraitValue(i.system.weapon.traits, "protection");
                      if (value > 0) {
                          armour += value;
                          armourText += `${i.name} +${value} `;
                      }
                  }
              } else if (i.type === "armour" && i.system.status === MgT2Item.EQUIPPED) {
                  if (i.system.armour.psi === "1") {
                      // Is Psi enhanced armour being worn?
                      let psi = this.system.characteristics["PSI"].current;
                      if (psi > 0) {
                          psi = parseInt((psi + 1) / 2);
                          armour += psi;
                          armourText += `PSI +${psi} `;
                      }
                  }
              }
          }

          // Check for radiation damage.
          if (radiationDamage > 0 && this.system.armour && isNonZero(this.system.armour.rad)) {
              options.armourRads = Number(this.system.armour.rad);
              radiationDamage = Math.max(0, Number(radiationDamage - options.armourRads));
          }

          options.finalArmour = armour;
          options.armourText = armourText;

          if (options.ap) {
              // If AP has already been calculated, use that.
              armour = Math.max(0, armour - options.ap);
          } else if (hasTrait(options.traits, "ap")) {
              let ap = parseInt(getTraitValue(options.traits, "ap"));
              armour = Math.max(0, armour - ap);
          } else if (hasTrait(options.traits, "loPen")) {
              let loPen = parseInt(getTraitValue(options.traits, "loPen"));
              if (loPen > 1) {
                  armour *= loPen;
              }
          }
          damage = Math.max(0, damage - armour);
          if (options.multiplier && parseInt(options.multiplier) > 1) {
              damage *= parseInt(options.multiplier);
          }
          if (damage < 1 && radiationDamage < 1) {
              // No damage to be applied.
              ui.notifications.info(
                  game.i18n.format("MGT2.Attack.DamageBounce",
                      {"target": this.name}
                  )
              );
              this.applyAnyAblatDamage(options);
              return;
          }
      }

      if (this.type === "traveller" || this.system.damage) {
          // This is a Traveller, so more complicated.
          if (options.noUI) {
              this.applyActualDamageToTraveller(damage, options);
          } else {
              new MgT2DamageDialog(this, damage, options).render(true);
          }
      } else {
          console.log("Damage non Traveller");
          // In this situation, we don't need an apply damage dialog. However, we want to verify
          // that the GM is happy for the player to apply damage to this token. So we need a simple
          // yes/no confirmation.
          if (options.playerRequestName) {
              let actorName = this.name;
              if (this.token) {
                  actorName = this.token.name;
              }
              let contentData = {
                  playerName: options.playerRequestName,
                  actorName: actorName,
                  actor: this,
                  damage: damage
              }
              const content = await renderTemplate("systems/mgt2e/templates/dialogs/apply-damage-check.html", contentData);

              let confirmed = false;
              try {
                  const yes = await foundry.applications.api.DialogV2.confirm({
                      window: {
                          title: game.i18n.format("MGT2.Dialog.ApplyDamage", {name: actorName})
                      },
                      content,
                      modal: true
                  });
                  if (yes) confirmed = true;
              } catch (e) {
                  // Dialog cancelled. Assume no.
              }
              if (!confirmed) {
                  return;
              }
          }
          this.applyActualDamageToPerson(damage, options);
      }
  }

  addDamageValues() {
      if (!this.system.damage) {
          this.system.damage = {
              "STR": { value: 0 },
              "DEX": { value: 0 },
              "END": { value: 0, tmp: 0 }
          }
          this.update({"system.damage": this.system.damage });
      }
  }

  async applyActualDamageToTraveller(damage, options) {
      let stun = false;
      let stuns = 0;
      if (hasTrait(options.traits, "stun")) {
          stun = true;
      }
      console.log("applyActualDamageToTraveller:");
      console.log(options);
      if (options.ablatItemId) {
          console.log("Ablating armour ");
          let i = this.items.get(options.ablatItemId);
          this.applyAnyAblatDamage(options, i);

      }
      if (options.directChaDamage) {
          // Damage it to be applied to specific characteristics, not
          // using the usual END/STR/DEX chain.
          for (let c in options.characteristics) {
              if (!this.system.damage[c]) {
                  this.system.damage[c] = { value: 0 };
              }
              this.system.damage[c].value += options.characteristics[c];
              this.system.damage[c].value = Math.min(this.system.damage[c].value, this.system.characteristics[c].value);
          }
          this.update({"system.damage": this.system.damage});
          return;
      }

      if (options.actualRadiation > 0) {
          this.system.rads += options.actualRadiation;
          this.update({ "system.rads": this.system.rads });
      }
      let totalDamage = damage;

      if (stun) {
          if (options.characteristics) {
              this.system.damage.END.value += parseInt(options.characteristics.END);
          } else {
              this.system.damage.END.value += parseInt(damage);
          }
          if (this.system.damage.END.value > this.system.characteristics.END.value) {
              stuns = this.system.damage.END.value - this.system.characteristics.END.value;
              this.system.damage.END.value = this.system.characteristics.END.value;
              let stunnedEffect = this.getEffect("stun");
              if (stunnedEffect) {
                  let v = stunnedEffect.getFlag("mgt2e", "value");
                  if (v && parseInt(v) !== NaN) {
                      v = parseInt(v) + stuns;
                  } else {
                      v = stuns;
                  }
                  stunnedEffect.setFlag("mgt2e", "value", v);
              } else {
                  this.setStunnedEffect(stuns);
              }
          }
      } else {
          let needsFirstAid = false;
          if (options.characteristics) {
              // Apply specific damage to each characteristic.
              this.system.damage.STR.value += parseInt(options.characteristics.STR);
              this.system.damage.DEX.value += parseInt(options.characteristics.DEX);
              this.system.damage.END.value += parseInt(options.characteristics.END);

              totalDamage = options.characteristics.STR + options.characteristics.DEX + options.characteristics.END;
              ui.notifications.info(game.i18n.format("MGT2.Info.Damage",
                  {"actor": this.name, "damage": totalDamage}))

              if (totalDamage > 0) {
                  needsFirstAid = true;
              }
          } else {
              // Split damage across characteristics.
              let dmgData = this.system.damage;
              let chaData = this.system.characteristics;
              let remaining = damage;
              if (remaining > 0) {
                  needsFirstAid = true;
              }

              if (dmgData.END.value < chaData.END.value) {
                  remaining = Tools.applyDamageToCha(remaining, this.system, "END");
              }
              if (remaining > 0) {
                  let str = this.system.characteristics.STR.current;
                  if (str <= this.system.characteristics.DEX.current && str > remaining) {
                      remaining = Tools.applyDamageToCha(remaining, this.system, "STR");
                      Tools.applyDamageToCha(remaining, this.system, "DEX");
                  } else {
                      remaining = Tools.applyDamageToCha(remaining, this.system, "DEX");
                      Tools.applyDamageToCha(remaining, this.system, "STR");
                  }
              }
              ui.notifications.info(game.i18n.format("MGT2.Info.Damage",
                  {"actor": this.name, "damage": damage}))

          }
          if (needsFirstAid) {
              console.log("Actor needs first aid, setting effect");
              this.setFirstAidEffect(true);
          }
      }

      for (let c of [ "STR", "DEX", "END"]) {
          this.system.damage[c].value = Math.min(this.system.damage[c].value, this.system.characteristics[c].value);
      }

      if (totalDamage > 0 || options.actualRadiation > 0) {
          let actorName = this?.token?.name?this.token.name:this.name;
          let wasInjured = this.effects.find(e => e.name === "injured");
          let wasUnconscious = this.effects.find(e => e.name === "unconscious");
          let wasDead = this.effects.find(e => e.name === "dead");
          let isInjured = false, isUnconscious = false, isDead = false;
          let numAtZero = 0;
          let END = Number(this.system.characteristics.END.value);

          if (this.system.damage.STR.value >= this.system.characteristics.STR.value) numAtZero++;
          if (this.system.damage.DEX.value >= this.system.characteristics.DEX.value) numAtZero++;
          if (this.system.damage.END.value >= this.system.characteristics.END.value) numAtZero++;
          if (numAtZero === 1) {
              isInjured = true;
          } else if (numAtZero === 2) {
              isUnconscious = true;
              this.setUnconsciousEffect(true);
          } else if (numAtZero === 3) {
              isDead = true;
              isUnconscious = false;
              this.setUnconsciousEffect(false);
              this.setDeadEffect(true);
          }

          let text = "";
          if (stun) {
              text = `${game.i18n.localize("MGT2.DamageTaken.Stun")} `;
          } else if (totalDamage >= END * 3) {
              text = `${game.i18n.localize("MGT2.DamageTaken.Critical")} `;
          } else if (totalDamage >= END * 2) {
              text = `${game.i18n.localize("MGT2.DamageTaken.Crippling")} `;
          } else if (totalDamage >= END) {
              text = `${game.i18n.localize("MGT2.DamageTaken.Severe")} `;
          } else if (totalDamage >= END /2) {
              text = `${game.i18n.localize("MGT2.DamageTaken.Major")} `;
          } else if (totalDamage > 0) {
              text = `${game.i18n.localize("MGT2.DamageTaken.Minor")} `;
          }
          if (options.actualRadiation > 0) {
              text += `${game.i18n.localize("MGT2.DamageTaken.Radiation")} `;
          }

          if (isDead && !wasDead) {
              text += game.i18n.localize("MGT2.DamageEffect.Dead");
          } else if (isUnconscious && !wasUnconscious) {
              text += game.i18n.localize("MGT2.DamageEffect.Unconscious");
          } else if (isInjured && !wasInjured) {
              text += game.i18n.localize("MGT2.DamageEffect.Injured");
          }

          let contentData = {
              useChatIcons: game.settings.get("mgt2e", "useChatIcons"),
              actor: this,
              text: text
          }
          const content = await renderTemplate("systems/mgt2e/templates/chat/damage-update.html", contentData);
          if (text.length > 0) {
              let chatData = {
                  user: game.user.id,
                  speaker: ChatMessage.getSpeaker(),
                  content: content
              }
              ChatMessage.create(chatData, {});
          }
      }


      this.update({"system.damage": this.system.damage });
  }

    /**
     * Damage after armour and multiplication.
     * @param damage    Actual damage to be applied.
     * @param options   List of options.
     */
  async applyActualDamageToPerson(damage, options) {
      let stun = false;
      if (hasTrait(options.traits, "stun")) {
          stun = true;
      }
      let hits = this.system.hits;
      let wasInjured = this.effects.find(e => e.name === "injured");
      let wasUnconscious = this.effects.find(e => e.name === "unconscious");
      let wasDead = this.effects.find(e => e.name === "dead");
      let isInjured = false, isUnconscious = false, isDead = false;

      if (stun) {
          if (!hits.tmpDamage) {
              hits.tmpDamage = 0;
          }
          let limit = parseInt(hits.max / 3 + 2);
          let stuns = 0;
          if (this.system.characteristics?.END?.value) {
              limit = this.system.characteristics.END.value;
          }
          // How many new stuns are over the END limit?
          if (hits.tmpDamage > limit) {
              stuns = damage;
          } else if (hits.tmpDamage + damage > limit) {
              stuns = damage - (limit - hits.tmpDamage);
          }

          hits.damage += (damage - stuns);
          hits.tmpDamage += (damage - stuns);
          if (stuns > 0) {
              this.setFlag("mgt2e", "stunned", true);
              this.setFlag("mgt2e", "stunnedRounds",
                  this.getFlag("mgt2e", "stunnedRounds") ?
                      parseInt(this.getFlag("mgt2e", "stunnedRounds")) + stuns : stuns
              );
          }
      } else {
          hits.damage = Math.min(hits.max, hits.damage + damage);
      }
      hits.value = Math.max(0, hits.max - hits.damage);
      this.update({"system.hits": this.system.hits});

      let text = "";
      if (options.isMinimumDamage) {
          text += `${game.i18n.localize("MGT2.DamageTaken.MinimumDamage")} `;
      } else if (options.isReducedDamage) {
          text += `${game.i18n.localize("MGT2.DamageTaken.ReducedDamage")} `;
      }
      if (stun) {
        text += `${game.i18n.localize("MGT2.DamageTaken.Stun")} `;
      } else {
          if (damage >= hits.max / 3) {
              text += `${game.i18n.localize("MGT2.DamageTaken.Creature.Heavy")} `;
          } else if (damage > 0) {
              text += `${game.i18n.localize("MGT2.DamageTaken.Creature.Light")} `;
          }
      }
      if (hits.value > hits.max / 2) {
          // Nothing.
      } else if (hits.value > hits.max / 10) {
          if (!wasInjured) {
              text += `${game.i18n.localize("MGT2.DamageEffect.Injured")} `;
          }
      } else if (hits.value > 0) {
          if (!wasUnconscious) {
              text += `${game.i18n.localize("MGT2.DamageEffect.Unconscious")} `;
              if (this.hasCreatureTrait("tough")) {
                  text += `${game.i18n.localize("MGT2.DamageTaken.Tough")} `;
              }
          }
      } else {
          if (!wasDead) {
              text += `${game.i18n.localize("MGT2.DamageEffect.Dead")} `;
              if (this.hasCreatureTrait("tough")) {
                  text += `${game.i18n.localize("MGT2.DamageTaken.Tough")} `;
              }
          }
      }

      let contentData = {
        useChatIcons: game.settings.get("mgt2e", "useChatIcons"),
        actor: this,
        text: text
      }
      const content = await renderTemplate("systems/mgt2e/templates/chat/damage-update.html", contentData);
      if (text.length > 0) {
        let chatData = {
          user: game.user.id,
          speaker: ChatMessage.getSpeaker(),
          content: content
        }
        ChatMessage.create(chatData, {});
      }
  }

  applyDamageToSpacecraft(damage, options) {
      if (hasTrait(options.traits, "stun")) {
          ui.notifications.info(game.i18n.format("MGT.Info.DamageMsg.SpacecraftNoStun"));
          return;
      }
      let armour = parseInt(this.system.spacecraft.armour);
      if (options.ap) {
          let ap = parseInt(options.ap);
          armour = Math.max(0, armour - ap);
      }
      if (options.isMissile) {
          console.log("MISSILE HIT");
          console.log(options);
          damage = options.damage;
      }
      damage = Math.max(0, damage - armour);
      if (options.multiplier && parseInt(options.multiplier) > 1) {
          damage *= parseInt(options.multiplier);
      }
      if (options.isMissile) {
          damage *= options.effect;
      }
      ui.notifications.info(game.i18n.format("MGT2.Info.Damage",
          { "actor": this.name, "damage": damage}))

      // Apply the damage to the spacecraft.
      options.originalDamage = this.system.hits.damage;

      new MgT2SpacecraftDamageDialog(this, damage, options).render(true);
  }

    /**
     * Damage after armour and other modifiers
     */
  applyActualDamageToSpacecraft(damage, options) {
      console.log(`applyActualDamageToSpacecraft: [${damage}]`);
        if (damage < 1) {
            return;
        }
        this.system.hits.damage += damage;
        this.system.hits.value = this.system.hits.max - this.system.hits.damage;
        this.update({"system.hits": this.system.hits});
  }

  applyDamageToVehicle(damage, options) {
      if (hasTrait(options.traits, "stun")) {
          ui.notifications.info(game.i18n.format("MGT.Info.DamageMsg.VehicleNoStun"));
          return;
      }

      //new MgT2VehicleDamageDialog(this, damage, options).render(true);

      let armour = 0;
      if (this.system.vehicle.armour && isNonZero(this.system.vehicle.armour.front)) {
          armour = parseInt(this.system.vehicle.armour.front);
      }
      if (options.ap) {
          let ap = parseInt(options.ap);
          armour = Math.max(0, armour - ap);
      }
      damage = Math.max(0, damage - armour);
      if (options.multiplier && parseInt(options.multiplier) > 1) {
          damage *= parseInt(options.multiplier);
      }
      ui.notifications.info(game.i18n.format("MGT2.Info.Damage",
          { "actor": this.name, "damage": damage}))

      this.system.hits.damage += damage;
      this.system.hits.value = this.system.hits.max - this.system.hits.damage;
      this.update({"system.hits": this.system.hits});
  }

  applyDamage(damage, options, multiSelect) {
      if (this.type === "spacecraft") {
          if (options.scale !== "spacecraft") {
              damage = parseInt(damage / 10);
          }
          this.applyDamageToSpacecraft(damage, options);
      } else if (this.type === "vehicle") {
          if (options.scale === "spacecraft") {
              damage *= 10;
          }
          this.applyDamageToVehicle(damage, options);
      } else if (this.type === "creature") {
          // Creatures can have special traits which modify damage.
          if (this.hasCreatureTrait("gigantic")) {
              if (options.scale !== "spacecraft") {
                  damage = parseInt(damage / 10);
              }
          } else if (options.scale === "spacecraft") {
              damage = Number(damage) * 10;
              // TODO: Possible also add blast effects.
          }
          if (this.hasCreatureTrait("energy")) {
              damage = 0;
          }
          if (this.hasCreatureTrait("particulate") && options.minimumDamage) {
              if (options.damageType !== "fire") {
                  options.isMinimumDamage = true;
                  damage = options.minimumDamage;
              }
          } else if (this.hasCreatureTrait("gossamer") && options.minimumDamage) {
              options.isMinimumDamage = true;
              damage = options.minimumDamage;
          } else if (this.hasCreatureTrait("dispersed") && options.reducedDamage) {
              if (options.damageType === "fire" || options.damageType === "cutting") {
                  // Normal damage.
              } else {
                  options.isReducedDamage = true;
                  damage = options.reducedDamage;
              }
          } else if (this.hasCreatureTrait("tough") && options.reducedDamage) {
              options.isReducedDamage = true;
              damage = options.reducedDamage;
          }
          this.applyDamageToPerson(damage, options);
      } else if (this.type === "traveller" || this.type === "npc" || this.type === "robot") {
          if (options.scale === "spacecraft") {
              damage *= 10;
              // TODO: Possibly also add blast effects.
          }
          this.applyDamageToPerson(damage, options);
      } else {
          // Don't apply damage to anything else.
      }
  }

  getWeaponSkill(weaponItem, options) {
      let score = this.getUntrained();

      if (weaponItem && weaponItem?.system?.weapon) {
          let skill = weaponItem.system.weapon.skill;
          if (options) {
              if (!options["cha"]) {
                  options["cha"] = weaponItem.system.weapon.characteristic;
              }
          }

          score = this.getSkillValue(skill, options);
          if (options) {
              if (!options.results) {
                  options.results = {};
              }
              options.results["cha"] = weaponItem.system.weapon.characteristic;
          }
      }

      return score;
  }

  getAttackSkill(weaponItem, options) {
      if (weaponItem && weaponItem?.system?.weapon) {
          let score = this.getWeaponSkill(weaponItem, options);

          if (isNonZero(weaponItem.system.weapon.attackBonus)) {
              score += parseInt(weaponItem.system.weapon.attackBonus);
              if (options?.results) {
                  options.results["weapon"] = parseInt(weaponItem.system.weapon.attackBonus);
              }
          }

          if (weaponItem.system.weapon.characteristic) {
              let cha = weaponItem.system.weapon.characteristic;
              if (this.system.characteristics[cha]) {
                  score += this.system.characteristics[cha].dm;
              }
          }

          return score;
      }
      return this.getUntrained();
  }
    getParrySkill(weaponItem, options) {
        if (weaponItem && weaponItem?.system?.weapon) {
            let score = this.getWeaponSkill(weaponItem, options);

            if (isNonZero(weaponItem.system.weapon.parryBonus)) {
                score += parseInt(weaponItem.system.weapon.parryBonus);
            }
            return score;
        }
        return this.getUntrained();
    }

    /**
     * Gets dice modifier for the given skill. Includes any bonuses for augments and
     * other modifiers on the characteristic or skill. Also includes global modifiers,
     * such as encumbrance or reaction penalties.
     *
     * @param skillId   Skill to get bonus for (skillId or skillId.specId)
     * @param options   Optional modifiers. Breakdown is returned in options.results
     * @returns {number}
     */
  getSkillValue(skillId, options) {
      let score = this.getUntrained();
      if (!options) {
          options = { "results": {} };
      } else {
          options.results = {
              "cha": null,
              "chadm": 0,
              "base": null,
              "expert": 0,
              "augment": 0,
              "augdm": 0,
              "bonus": 0,
              "label": this.getSkillLabel(skillId),
              "dice": "2D6",
              "addcha": false
          };
      }

      let id = skillId;
      let spId = null;
      let cha = null;
      if (skillId.indexOf(".") > -1) {
          id = skillId.split(".")[0];
          spId = skillId.split(".")[1];
      }
      if (this.system.skills[id]) {
          let skill = this.system.skills[id];
          let spec = null;
          if (spId && skill.specialities && skill.specialities[spId]) {
              spec = skill.specialities[spId];
          }

          // Set characteristic to use.
          if (options.cha) {
              cha = options.cha;
          } else {
              if (skill.default) {
                  cha = skill.default;
              }
              if (spec && spec.default) {
                  cha = spec.default;
              }
          }
          options.results.cha = cha;
          if (skill.trained) {
              if (spec) {
                  score = isNonZero(spec.value)?parseInt(spec.value):0;
                  options.results.base = score;

                  if (isNonZero(spec.expert) && (cha === "INT" || cha === "EDU")) {
                      score = Math.max(score + 1, parseInt(spec.expert) - 1);
                      options.results.expert = spec.expert;
                  }
                  // Only adds if skill is trained.
                  if (isNonZero(spec.augment)) {
                      score += parseInt(spec.augment);
                  }
              } else {
                  score = isNonZero(skill.value)?parseInt(skill.value):0;
                  options.results.base = score;
                  if (isNonZero(skill.expert) && (cha === "INT" || cha === "EDU")) {
                      score = Math.max(score + 1, parseInt(skill.expert) - 1);
                      options.results.expert = skill.expert;
                  }
                  // Only adds if skill is trained.
                  if (isNonZero(skill.augment)) {
                      score += parseInt(skill.augment);
                  }
              }
          } else {
              if (spec) {
                  if (isNonZero(spec.expert)) {
                      score = parseInt(spec.expert);
                      options.results.expert = score;
                  }
              } else {
                  if (isNonZero(skill.expert) === "number") {
                      score = parseInt(skill.expert);
                      options.results.expert = score;
                  }
              }
          }
          // The following are always applied. Parent and specialities stack.
          if (isNonZero(skill.bonus) === "number") {
              score += parseInt(skill.bonus);
              options.results.bonus += parseInt(skill.bonus);
          }
          if (isNonZero(skill.augdm) === "number") {
              score += parseInt(skill.augdm);
              options.results.augdm += parseInt(skill.augdm);
          }
          if (spec && isNonZero(spec.bonus)) {
              score += parseInt(spec.bonus);
              options.results.bonus += parseInt(spec.bonus);
          }
          if (spec && isNonZero(spec.augdm)) {
              score += parseInt(spec.augdm);
              options.results.augdm += parseInt(spec.augdm);
          }
      }

      // Apply global modifiers.
      if (isNonZero(options.dm)) {
          score += parseInt(options.dm);
          options.results["dm"] = parseInt(options.dm);
      }
      if (cha && this.system[cha]) {
          if (options.addcha) {
              score += parseInt(this.system[cha]);
          }
          options.results["chadm"] = parseInt(this.system[cha]);
      }

      return score;
  }

  getSkillIcon(skillId) {
      let skill = this.system.skills[skillId.replaceAll(/\..*/g, "")];
      if (!skill) {
          return "systems/mgt2e/icons/skills/untrained.svg";
      }
      if (skill.icon) {
          return skill.icon;
      }
      return `systems/mgt2e/icons/skills/${skillId}.svg`;
  }

  getSkillLabel(skill, showValue) {
      if (!skill) {
          return "";
      }
      let skillId = skill;
      let specId = null;
      if (skill.indexOf(".") > -1) {
          skillId = skill.replaceAll(/\..*/g, "");
          specId = skill.replaceAll(/.*\./g, "");
      }
      let text = "";
      let spec = null;
      let SKILLS = MGT2.getDefaultSkills();
      if (this.system.skills) {
          SKILLS = this.system.skills;
      }
      skill = SKILLS[skillId];
      if (!skill) {
          return "";
      }
      if (skill.label) {
          text = skill.label;
      } else {
          text = game.i18n.localize("MGT2.Skills." + skillId);
          if (text.indexOf("MGT2.Skills") === 0) {
              text = skillId;
          }
      }
      if (specId) {
          if (skill.specialities && skill.specialities[specId]) {
              spec = skill.specialities[specId];
              if (spec.label) {
                  text += ` (${spec.label})`;
              } else {
                let label =  game.i18n.localize("MGT2.Skills." + specId);
                if (label.indexOf("MGT2.Skills") === 0) {
                    text += ` (${specId})`;
                } else {
                    text += ` (${label})`;
                }
              }
          }
      }

      if (showValue) {
          let value = this.getUntrained();
          if (skill.trained && spec) {
              value = spec.value;
          } else if (skill.trained) {
              value = skill.value;
          }
          text += ` ${value}`;
      }

      return text;
  }

  async rollUPP(options) {
      let upp = this.system.characteristics;

      if (!options) {
          options = {};
      }

      if (upp) {
          let html=`<div class="chat-package">`;
          html += `<p><b>${this.name}</b></p>`;
          html += `<div class="stats grid grid-3col">`;

          let prefix = options.shift?"~":"";
          for (let c in upp) {
              if (upp[c].show) {
                  let dice = "2D6";
                  if (options.ctrl) {
                      let roll = await new Roll("2D6", this.getRollData()).evaluate();
                      let modifier = 0;
                      switch (roll.total) {
                          case 2:
                              modifier = -2;
                              break;
                          case 3: case 4:
                              modifier = -1;
                              break;
                          case 10: case 11:
                              modifier = +1;
                              break;
                          case 12:
                              modifier = +2;
                              break;
                      }
                      upp[c].value += modifier;
                      html += `<div class="stat resource"><span class="stat-hdr">${c}</span><span class="stat-val">+/-<br/>${(modifier>=0)?("+"+modifier):modifier}</span></div>`;
                  } else {
                      if (upp[c].roll) {
                          dice = upp[c].roll;
                      }
                      if (options.shift) {
                          let totals = [];
                          for (let i=0; i < 5; i++) {
                              let roll = await new Roll(dice, this.getRollData()).evaluate();
                              totals.push(roll.total);
                          }
                          totals = totals.sort(function(a, b) {
                              return a - b;
                          });
                          upp[c].value = totals[2];
                      } else {
                          let roll = await new Roll(dice, this.getRollData()).evaluate();
                          upp[c].value = roll.total;
                      }
                      html += `<div class="stat resource"><span class="stat-hdr">${c}</span><span class="stat-val">${prefix}${dice}<br/>${upp[c].value}</span></div>`;
                  }
              }
          }
          this.update({"system.characteristics": upp});
          html += "</div></div>";

          if (!options.quiet) {
              let who = null;
              if (game.users.current.isGM) {
                  if (game.settings.get("mgt2e", "gmSheetNotification") === "private") {
                      who = [game.user.id];
                  }
              } else {
                  if (game.settings.get("mgt2e", "playerSheetNotification") === "private") {
                      who = [game.user.id];
                  } else if (game.settings.get("mgt2e", "playerSheetNotification") === "gm") {
                      who = [game.user.id, game.users.activeGM ];
                  }
              }
              let chatData = {
                  user: game.user.id,
                  speaker: ChatMessage.getSpeaker(),
                  whisper: who,
                  content: html
              }
              ChatMessage.create(chatData, {});
          }
      }
  }

  getCriticalLevel(critical) {
      if (this.type === "spacecraft") {
          if (MGT2.SPACECRAFT_CRITICALS[critical]) {
              let value = this.getFlag("mgt2e", "crit_" + critical);
              if (value && parseInt(value) > 0) {
                  return Math.min(6, parseInt(value));
              }
          } else {
              console.log(`WARN: Unknown spacecraft critical [${critical}]`);
          }
      }
      return 0;
  }

  async setCriticalLevel(critical, level) {
      await setSpacecraftCriticalLevel(this, critical, level);
  }

  fixCriticalEffect(effect) {
      this.unsetFlag("mgt2e", "damage_" + effect);
      this.unsetFlag("mgt2e", "damageSev_" + effect);
  }


  getHardwareList(type) {
      let list = [];
      for (let i of this.items.contents) {
          if (i.type === "hardware" && i.system.hardware.system === type) {
              list.push(i);
          }
      }
      return list;
  }

  getItemsByType(type) {
      let list = [];
      for (let i of this.items.contents) {
          if (i.type === type) {
              list.push(i);
          }
      }
      return list;
  }

    printCreatureBehaviours() {
        let text = "";
        if (this.type === "creature" && this.system.behaviour) {
            const behaviours = this.system.behaviour.split(" ");
            for (let b of behaviours) {
                if (CONFIG.MGT2.CREATURES.behaviours[b]) {
                    let label = game.i18n.localize("MGT2.Creature.Behaviour." + b);
                    if (text) {
                        text += ", ";
                    }
                    text += label.replace(/ /g, "&nbsp;");
                }
            }
        }
        return text;
    }

    printCreatureTraits(includeDerived) {
        let text = "";
        if (this.type === "creature" && (includeDerived || this.system.traits)) {

            if (includeDerived) {
                if (this.system.size !== 0) {
                    text += "Size (" + this.system.size + ")";
                }
                if (this.system.armour.protection !== 0) {
                    if (text) {
                        text += ", ";
                    }
                    text += "Armour (" + this.system.armour.protection + ")";
                }
            }

            const traits = this.system.traits.split(",");
            for (let t of traits) {
                const trait = t.replaceAll(/[^a-zA-Z]/g, "");
                const value = t.replaceAll(/[^0-9]/g, "");
                if (CONFIG.MGT2.CREATURES.traits[trait]) {
                    let label = game.i18n.localize("MGT2.Creature.Trait." + trait);
                    if (text) {
                        text += ", ";
                    }
                    text += label.replace(/ /g, "&nbsp;");
                    if (value) {
                        text += " " + value;
                    }
                }
            }
        }
        return text;
    }

    printSkills() {
        const skills = this.system.skills;
        if (!skills) {
            return;
        }
        let html = "";
        for (let key in skills) {
            let skill = skills[key];

            if (skill.trained) {
                let showParent = true;
                if (skill.specialities) {
                    for (let specKey in skill.specialities) {
                        let spec = skill.specialities[specKey];
                        if (spec.value > 0) {
                            showParent = false;
                            html += `<li>${skillLabel(skill, key).replace(/ /, "&nbsp;")}&nbsp;(${skillLabel(spec, specKey).replace(/ /, "&nbsp;")})&nbsp;${spec.value}</li>`;
                        }
                    }
                }
                if (showParent) {
                    html += `<li>${skillLabel(skill, key).replace(/ /, "&nbsp;")}&nbsp;${skill.value}</li>`;
                }
            }
        }
        return `<ul class="skill-list">${html}</ul>`;
    }

    printAttacks() {
      console.log("printAttacks:");
      if (this.type !== "creature" && this.type !== "npc" && this.type !== "traveller") {
          return "";
      }
      let html = "";
      for (let i of this.items) {
          if (i.type === "weapon" && (i.type !== "creature" || i.system.status === MgT2Item.ACTIVE)) {
              if (html) {
                  html += ", ";
              }
              html += `<span>${i.name} (${i.system.weapon.damage})</span>`;
          }
      }

      return html;
    }

    safeUpdate(data) {
        let u = game.user;
        if ((u.isGM || this.canUserModify(u)) && !this.compendium?.locked) {
            return this.update(data);
        }
        return null;
    }

    async syncedUpdate(data) {
        let u = game.user;
        if ((u.isGM || this.canUserModify(game.user)) && !this.compendium?.locked) {
            return await this.update(data);
        }
        return null;
    }

    getEffect(status) {
        const statusEffect = CONFIG.statusEffects.find(e => e.id === status);

        if (!statusEffect) {
            ui.notifications.error(
                game.i18n.format("MGT2.Error.NoStatus", { status: status })
            );
            return null;
        }

        const name = game.i18n.localize(statusEffect.name);
        return this.effects.find(e => e.name === name);
    }

    async setEffect(status, value, overlay, locked, css, changes) {
        const statusEffect = CONFIG.statusEffects.find(e => e.id === status);
        if (!changes) {
            changes = [];
        }
        console.log("setEffect: " + status + " " + value);

        if (!statusEffect) {
            ui.notifications.error(
                game.i18n.format("MGT2.Error.NoStatus", { status: status })
            );
            return false;
        }

        const name = game.i18n.localize(statusEffect.name);
        const effect = this.effects.find(e => e.name === name);

        if (value && effect) {
            if (isNaN(parseInt(value))) {
                return false;
            } else if (effect.flags?.mgt2e?.value) {
                // Passed in a numerical value. Need to +/- it.
                let current = parseInt(effect.flags?.mgt2e?.value);
                if (!isNaN(current) && current !== 0) {
                    if (CONFIG.MGT2.STATUS_EFFECTS[status]?.replace) {
                        current = parseInt(value);
                    } else {
                        current += parseInt(value);
                    }
                    effect.setFlag("mgt2e", "value", current);
                    if (!CONFIG.MGT2.STATUS_EFFECTS[status]?.mono) {
                        if (current < 0) {
                            effect.setFlag("mgt2e", "css", "statusWarn");
                        } else if (current > 0) {
                            effect.setFlag("mgt2e", "css", "statusGood");
                        }
                    }
                    if (effect.changes && effect.changes.length > 0) {
                        effect.changes[0].value = current;
                        await effect.update({"changes": effect.changes});
                    }
                } if (current === 0) {
                    await effect.delete();
                }
            }
            return false;
        } else if (!value && !effect) {
            return false;
        } else if (value) {
            await this.createEmbeddedDocuments("ActiveEffect", [{
                name: name,
                icon: statusEffect.img,
                changes: changes,
                statuses: [ status ],
                flags: {
                    "core": {
                        overlay: overlay
                    },
                    "mgt2e": {
                        effect: status,
                        locked: locked?true:false,
                        css: "status" + css,
                        value: value
                    }
                }
            }]);
        } else if (effect) {
            try {
                await effect.delete();
                return true;
            } catch (e) {
                // Already deleted.
            }
            return false;
        }
        return true;
    }

    addStatusEffect(status, value) {
        if (value === undefined) {
            if (CONFIG.MGT2.STATUS_EFFECTS[status]) {
                if (CONFIG.MGT2.STATUS_EFFECTS[status].value !== undefined) {
                    value = CONFIG.MGT2.STATUS_EFFECTS[status].value;
                } else {
                    value = true;
                }
            }
        }

        switch (status) {
            case "dead":
                this.setDeadEffect(true);
                break;
            case "unconscious":
                this.setUnconsciousEffect(true);
                break;
            case "injured":
                this.setInjuredEffect(true);
                break;
            case "fear":
                this.setFearEffect(true);
                break;
            case "stunned":
                this.setStunnedEffect(value);
                break;
            case "needsFirstAid":
                this.setFirstAidEffect(true);
                true;
            case "needsSurgery":
                this.setSurgeryEffect(true)
                break;
            case "destroyed":
                this.setDestroyedEffect(true);
                break;
            case "aware":
                this.setAwareEffect(true);
                break;
            case "surprised":
                this.setSurprisedEffect(true);
                break;
            case "fatigued":
                this.setFatiguedEffect(true);
                break;
            case "inCover":
                this.setInCoverEffect(value);
                break;
            case "hiding":
                this.setHidingEffect(value);
                break;
            case "prone":
                this.setProneEffect(true);
                break;
            case "armour":
                this.setArmourEffect(1);
                break;
            case "physical":
                this.setPhysicalEffect(value);
                break;
            case "melee":
                this.setMeleeEffect(value);
                break;
            case "gunCombat":
                this.setGunCombatEffect(value);
                break;
            case "tactics":
                this.setTacticsEffect(1);
                break;
            case "reaction":
                this.setReactionEffect(-1);
                break;
        }
    }

    setDeadEffect(value) {
        this.setEffect("dead", value, true, false,"Bad");
    }

    setUnconsciousEffect(value) {
        this.setEffect("unconscious", value,  true, false, "Bad");
    }

    setInjuredEffect(value) {
        this.setEffect("injured", value,  false, false, "Warn");
    }

    setFearEffect(value) {
        this.setEffect("fear", value,  false, false, "Warn");
    }

    setStunnedEffect(value) {
        return this.setEffect("stunned", value,  false, false, "Bad");
    }

    setFirstAidEffect(value) {
        this.setEffect("needsFirstAid", value,  false, false, "Warn");
    }

    setSurgeryEffect(value) {
        this.setEffect("needsSurgery", value,  false, false, "Bad");
    }

    setDestroyedEffect(value) {
        this.setEffect("destroyed", value,  true, false, "Bad");
    }

    async setEncumberedEffect(value) {
        await this.setEffect("encumbered", value,  false, true, "Warn");
    }

    async setVaccSuitEffect(value) {
        await this.setEffect("vaccSuit", value,  false, true, "Warn");
    }

    setAwareEffect(value) {
        this.setEffect("aware", value,  false, false, "Good");
    }

    setSurprisedEffect(value) {
        this.setEffect("surprised", value,  false, false, "Warn");
    }

    setReactionEffect(value) {
        this.setEffect("reaction", value,  false, false, "Warn");
    }

    setFatiguedEffect(value) {
      this.setEffect("fatigued", value, false, false, "Warn",
          [
              { key: "system.modifiers.physical.effect", mode: 2, priority: 0, value: -2 }
          ]);
    }
    setPhysicalEffect(value) {
        let css= "Warn";
        if (parseInt(value) > 0) {
            css = "Good";
        }
        this.setEffect("physical", value, false, false, css,
            [
                { key: "system.modifiers.physical.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }
    setMeleeEffect(value) {
        let css= "Warn";
        if (parseInt(value) > 0) {
            css = "Good";
        }
        this.setEffect("melee", value, false, false, css,
            [
                { key: "system.modifiers.melee.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }
    setGunCombatEffect(value) {
        let css= "Warn";
        if (parseInt(value) > 0) {
            css = "Good";
        }
        this.setEffect("gunCombat", value, false, false, css,
            [
                { key: "system.modifiers.guncombat.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }
    setArmourEffect(value) {
        this.setEffect("armour", value, false, false, "Good",
            [
                { key: "system.modifiers.armour.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }
    setInCoverEffect(value) {
        this.setEffect("inCover", value, false, false, "Good");
    }
    setHidingEffect(value) {
        this.setEffect("hiding", value, false, false, "Good",
            [
                { key: "system.modifiers.armour.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }
    setProneEffect(value) {
        this.setEffect("prone", value, false, false, "Good");
    }
    setInCoverEffect(value) {
        this.setEffect("inCover", value, false, false, "Good",
            [
                { key: "system.modifiers.armour.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }
    setTacticsEffect(value) {
        this.setEffect("tactics", value, false, false, "Good",
            [
                { key: "system.modifiers.initiative.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }
    setInitiativeEffect(value) {
        this.setEffect("initiative", value, false, false, "Good",
            [
                { key: "system.modifiers.initiative.effect", mode: 2, priority: 0, value: parseInt(value) }
            ]);
    }

}
