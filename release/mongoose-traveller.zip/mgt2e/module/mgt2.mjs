// Import document classes.
// noinspection JSUnresolvedVariable,JSUnresolvedFunction

import { MgT2Actor } from "./documents/actor.mjs";
import { MgT2Item } from "./documents/item.mjs";
// Import sheet classes.
import { MgT2ActorSheet } from "./sheets/actor-sheet.mjs";
import { MgT2NpcActorSheet } from "./sheets/actors/npc.mjs";
import { MgT2CreatureActorSheet } from "./sheets/actor-sheet.mjs";
import { MgT2WorldActorSheet } from "./sheets/actors/world.mjs";
import { MgT2VehicleActorSheet } from "./sheets/actors/vehicle.mjs";
import { MgT2SwarmActorSheet } from "./sheets/actors/swarm.mjs";
import { MgT2ItemSheet } from "./sheets/item-sheet.mjs";
import { MgT2EffectSheet } from "./sheets/effect-sheet.mjs";
import { MgT2AssociateItemSheet } from "./sheets/items/associate.mjs";
import { MgT2WorldDataItemSheet } from "./sheets/items/world-data.mjs";
import { MgT2SoftwareItemSheet } from "./sheets/items/software.mjs";
import { MgT2eVehicleSheet } from "./sheets/v2/Vehicle.mjs";
import { MgT2eRobotSheet } from "./sheets/v2/Robot.mjs";
import { MgT2eOptionSheet } from "./sheets/items/v2/Option.mjs";

// Import helper/utility classes and constants.
import { preloadHandlebarsTemplates } from "./helpers/templates.mjs";
import { MGT2 } from "./helpers/config.mjs";
import { Tools } from "./helpers/chat/tools.mjs";
import { MgT2eMacros } from "./helpers/chat/macros.mjs";
import { printWeaponTraits, rollSkill } from "./helpers/dice-rolls.mjs";
import { skillLabel } from "./helpers/dice-rolls.mjs";
import {MgT2Effect} from "./documents/effect.mjs";
import { migrateWorld } from "./migration.mjs";
import { NpcIdCard } from "./helpers/id-card.mjs";
import {hasTrait} from "./helpers/dice-rolls.mjs";
import {
    tradeBuyGoodsHandler,
    tradeSellGoodsHandler,
    tradeBuyFreightHandler,
    tradeSellFreightHandler,
    tradeEmbarkPassengerHandler, tradeDisembarkPassengerHandler
} from "./helpers/utils/trade-utils.mjs";
import { worldDropBrokerHandler } from "./helpers/utils/world-utils.mjs";
import {generateNpc, generateText} from "./helpers/utils/npcgen-utils.mjs";
import {
    launchSwarmHandler, showSwarmHandler
} from "./helpers/spacecraft/spacecraft-utils.mjs";
import {onManageActiveEffect} from "./helpers/effects.mjs";
const  { renderTemplate } = foundry.applications.handlebars;

const { Actors, Items } = foundry.documents.collections;
const { ActorSheet, ItemSheet } = foundry.appv1.sheets;
//const { ActiveEffectConfig } = foundry.applications.sheets.ActiveEffectConfig;
//const { DocumentSheetConfig } = foundry.applications.apps.DocumentSheetConfig;

/* -------------------------------------------- */
/*  Init Hook                                   */
/* -------------------------------------------- */

Hooks.once('init', async function() {

  // Add utility classes to the global game object so that they're more easily
  // accessible in global contexts.
    game.mgt2e = {
        MgT2Actor,
        MgT2Item,
        rollSkillMacro,
        rollAttackMacro,
        generateNpc,
        generateText
    };

    game.settings.register("mgt2e", "systemSchemaVersion", {
        config: false,
        scope: "world",
        type: Number,
        default: 0
    });

    game.settings.register("mgt2e", "lastVersionReported", {
        config: false,
        scope: "world",
        type: String,
        default: "0.0.0"
    });

    game.settings.register('mgt2e', 'verboseSkillRolls', {
        name: game.i18n.localize("MGT2.Settings.Verbose.Name"),
        hint: game.i18n.localize("MGT2.Settings.Verbose.Hint"),
        scope: 'world',
        config: true,
        type: Boolean,
        default: true,
        onChange: value => {
            console.log(`Setting verboseSkillRolls to ${value}`)
        }
    });
    game.settings.register('mgt2e', 'useChatIcons', {
        name: game.i18n.localize("MGT2.Settings.ChatIcons.Name"),
        hint: game.i18n.localize("MGT2.Settings.ChatIcons.Hint"),
        scope: 'world',
        config: true,
        type: Boolean,
        default: true,
        onChange: value => {
            console.log(`Setting iconsInChat to ${value}`)
        }
    });
    game.settings.register('mgt2e', 'useEncumbrance', {
        name: game.i18n.localize("MGT2.Settings.UseEncumbrance.Name"),
        hint: game.i18n.localize("MGT2.Settings.UseEncumbrance.Hint"),
        scope: 'world',
        config: true,
        type: Boolean,
        default: true
    });
    game.settings.register('mgt2e', 'quickRolls', {
        name: game.i18n.localize("MGT2.Settings.QuickRolls.Name"),
        hint: game.i18n.localize("MGT2.Settings.QuickRolls.Hint"),
        scope: 'client',
        config: true,
        type: Boolean,
        default: false,
        onChange: value => {
            console.log(`Setting quickRolls to ${value}`)
        }
    });
    game.settings.register('mgt2e', 'npcChaDamage', {
        name: game.i18n.localize("MGT2.Settings.NPCChaDamage.Name"),
        hint: game.i18n.localize("MGT2.Settings.NPCChaDamage.Hint"),
        scope: 'world',
        config: true,
        type: Boolean,
        default: true
    });
    game.settings.register('mgt2e', 'skillColumns', {
        name: game.i18n.localize("MGT2.Settings.SkillColumns.Name"),
        hint: game.i18n.localize("MGT2.Settings.SkillColumns.Hint"),
        scope: 'client',
        config: true,
        type: String,
        choices: {
            "2": game.i18n.localize("MGT2.Settings.SkillColumns.Values.Two"),
            "3": game.i18n.localize("MGT2.Settings.SkillColumns.Values.Three")
        },
        default: "3"
    });
    game.settings.register('mgt2e', 'skillFormat', {
        name: game.i18n.localize("MGT2.Settings.SkillFormat.Name"),
        hint: game.i18n.localize("MGT2.Settings.SkillFormat.Hint"),
        scope: 'client',
        config: true,
        type: String,
        choices: {
            "rows": game.i18n.localize("MGT2.Settings.SkillFormat.Values.Rows"),
            "columns": game.i18n.localize("MGT2.Settings.SkillFormat.Values.Columns")
        },
        default: "columns"
    });

    game.settings.register('mgt2e', 'currentYear', {
       name: game.i18n.localize("MGT2.Settings.CurrentYear.Name"),
       hint: game.i18n.localize("MGT2.Settings.CurrentYear.Hint"),
       scope: 'world',
       config: true,
       type: Number,
       default: 1105
    });
    game.settings.register('mgt2e', 'currentDay', {
        name: game.i18n.localize("MGT2.Settings.CurrentDay.Name"),
        hint: game.i18n.localize("MGT2.Settings.CurrentDay.Hint"),
        scope: 'world',
        config: true,
        type: Number,
        default: 1
    });
    game.settings.register('mgt2e', 'autoResizeSpacecraft', {
        name: game.i18n.localize("MGT2.Settings.AutoResizeSpacecraft.Name"),
        hint: game.i18n.localize("MGT2.Settings.AutoResizeSpacecraft.Hint"),
        scope: 'world',
        config: false,
        type: Boolean,
        default: true
    });
    game.settings.register('mgt2e', 'playerSheetNotification', {
        name: game.i18n.localize("MGT2.Settings.PlayerSheetNotification.Name"),
        hint: game.i18n.localize("MGT2.Settings.PlayerSheetNotification.Hint"),
        scope: 'world',
        config: true,
        choices: {
            "private": game.i18n.localize("MGT2.Settings.SheetNotification.Values.Private"),
            "public": game.i18n.localize("MGT2.Settings.SheetNotification.Values.Public"),
            "gm": game.i18n.localize("MGT2.Settings.SheetNotification.Values.GM")
        },
        default: "gm"
    });
    game.settings.register('mgt2e', 'gmSheetNotification', {
        name: game.i18n.localize("MGT2.Settings.GMSheetNotification.Name"),
        hint: game.i18n.localize("MGT2.Settings.GMSheetNotification.Hint"),
        scope: 'world',
        config: true,
        choices: {
            "private": game.i18n.localize("MGT2.Settings.SheetNotification.Values.Private"),
            "public": game.i18n.localize("MGT2.Settings.SheetNotification.Values.Public")
        },
        default: "private"
    });
    game.settings.register('mgt2e', 'visionDefaultTraveller', {
        name: game.i18n.localize("MGT2.Settings.PlayerVision.Traveller.Name"),
        hint: game.i18n.localize("MGT2.Settings.PlayerVision.Traveller.Hint"),
        scope: 'world',
        config: false,
        type: Boolean,
        default: false
    });
    game.settings.register('mgt2e', 'visionDefaultNPC', {
        name: game.i18n.localize("MGT2.Settings.PlayerVision.NPC.Name"),
        hint: game.i18n.localize("MGT2.Settings.PlayerVision.NPC.Hint"),
        scope: 'world',
        config: false,
        type: Boolean,
        default: false
    });
    game.settings.register('mgt2e', 'visionDefaultCreature', {
        name: game.i18n.localize("MGT2.Settings.PlayerVision.Creature.Name"),
        hint: game.i18n.localize("MGT2.Settings.PlayerVision.Creature.Hint"),
        scope: 'world',
        config: false,
        type: Boolean,
        default: false
    });
    game.settings.register('mgt2e', 'visionDefaultSpacecraft', {
        name: game.i18n.localize("MGT2.Settings.PlayerVision.Spacecraft.Name"),
        hint: game.i18n.localize("MGT2.Settings.PlayerVision.Spacecraft.Hint"),
        scope: 'world',
        config: false,
        type: Boolean,
        default: false
    });
    game.settings.register('mgt2e', 'autoPlayerCharacter', {
        name: game.i18n.localize("MGT2.Settings.AutoPlayerCharacter.Name"),
        hint: game.i18n.localize("MGT2.Settings.AutoPlayerCharacter.Hint"),
        scope: 'world',
        config: true,
        type: Boolean,
        default: true
    });
    game.settings.register('mgt2e', 'defaultTraveller', {
        name: game.i18n.localize("MGT2.Settings.DefaultTraveller.Name"),
        hint: game.i18n.localize("MGT2.Settings.DefaultTraveller.Hint"),
        scope: 'world',
        config: true,
        type: String,
        default: "DEFAULT TRAVELLER"
    });
    game.settings.register('mgt2e', 'blastEffectDivergence', {
        name: game.i18n.localize("MGT2.Settings.BlastEffectDivergence.Name"),
        hint: game.i18n.localize("MGT2.Settings.BlastEffectDivergence.Hint"),
        scope: 'world',
        config: true,
        "choices": {
            "0": "None",
            "1": "Low",
            "2": "Medium",
            "3": "High"
        },
        default: "0"
    });
    game.settings.register('mgt2e', "splitAttackDamage", {
       name: game.i18n.localize("MGT2.Settings.SplitAttackDamage.Name"),
       hint: game.i18n.localize("MGT2.Settings.SplitAttackDamage.Hint"),
       scope: "client",
       config: true,
       type: Boolean,
       default: false
    });
    game.settings.register('mgt2e', "hexInWorldMenus", {
        name: game.i18n.localize("MGT2.Settings.HexInWorldMenus.Name"),
        hint: game.i18n.localize("MGT2.Settings.HexInWorldMenus.Hint"),
        scope: "client",
        config: true,
        type: Boolean,
        default: false
    });
    game.settings.register('mgt2e', "damageManager", {
        name: game.i18n.localize("MGT2.Settings.DamageManager.Name"),
        hint: game.i18n.localize("MGT2.Settings.DamageManager.Hint"),
        scope: "world",
        config: true,
        type: String,
        default: ""
    });

    // Add custom constants for configuration.
    CONFIG.MGT2 = MGT2;

  /**
   * Set an initiative formula for the system
   * @type {String}
   */
  CONFIG.Combat.initiative = {
    formula: "2D6 - 8 + @initiative.value",
    decimals: 0
  };

  // v13 only: https://foundryvtt.wiki/en/development/api/sockets
  // CONFIG.queries["mgt2e.tradeBuyGoods"] = tradeBuyGoodsHandler;

  // Define custom Document classes
  CONFIG.Actor.documentClass = MgT2Actor;
  CONFIG.Item.documentClass = MgT2Item;
  CONFIG.ActiveEffect.documentClass = MgT2Effect;

  //CONFIG.debug.hooks = true;

  // Register sheet application classes
  Actors.unregisterSheet("core", ActorSheet);
  Actors.registerSheet("mgt2e", MgT2ActorSheet, { label: "Traveller Sheet", makeDefault: true });
  Actors.registerSheet("mgt2e", MgT2NpcActorSheet, { label: "NPC Sheet", types: [ "npc"], makeDefault: false });
  Actors.registerSheet("mgt2e", MgT2CreatureActorSheet, { label: "Creature Sheet", types: [ "creature"], makeDefault: false });
  Actors.registerSheet("mgt2e", MgT2WorldActorSheet, { label: "World Sheet", types: [ "world"], makeDefault: true });
  Actors.registerSheet("mgt2e", MgT2VehicleActorSheet, { label: "Vehicle Sheet", types: [ "vehicle"], makeDefault: true });
  Actors.registerSheet("mgt2e", MgT2eVehicleSheet, { label: "Vehicle Sheet 2", types: [ "vehicle"], makeDefault: false });
  Actors.registerSheet("mgt2e", MgT2eRobotSheet, { label: "Robot Sheet", types: [ "robot"], makeDefault: true });
  Actors.registerSheet("mgt2e", MgT2SwarmActorSheet, { label: "Swarm Sheet", types: [ "swarm"], makeDefault: true });
  Items.unregisterSheet("core", ItemSheet);
  Items.registerSheet("mgt2e", MgT2ItemSheet, { label: "Item Sheet", makeDefault: true });
  Items.registerSheet("mgt2e", MgT2AssociateItemSheet, { label: "Associate Sheet", types: [ "associate"], makeDefault: true });
  Items.registerSheet("mgt2e", MgT2WorldDataItemSheet, { label: "World Data Sheet", types: [ "worlddata"], makeDefault: true });
  Items.registerSheet("mgt2e", MgT2SoftwareItemSheet, { label: "Software", types: [ "software"], makeDefault: true });
  Items.registerSheet("mgt2e", MgT2eOptionSheet, { label: "Option", types: [ "option"], makeDefault: true });

  foundry.applications.apps.DocumentSheetConfig.unregisterSheet(ActiveEffect, "core", foundry.applications.sheets.ActiveEffectConfig);
  foundry.applications.apps.DocumentSheetConfig.registerSheet(ActiveEffect, "mgt2e", MgT2EffectSheet, { makeDefault: true});
//  ActiveEffects.unregisterSheet("core", ActiveEffectSheet);
//  ActiveEffects.registerSheet("mgt2e", MgT2EffectSheet, { makeDefault: true });

    // Sockets
    game.socket.on("system.mgt2e", (data) => {
        if (game.user.uuid === data.userId) {
            if (data.type === "showSwarm") {
                showSwarmHandler(data);
            } else if (data.type === "applyDamageToActor" || data.type === "applyDamageToPerson") {
                Tools.applyDamageHandler(data);
            }
        } else if (game.user === game.users.activeGM) {
            if (data.type === "tradeBuyGoods") {
                tradeBuyGoodsHandler(data);
            } else if (data.type === "tradeSellGoods") {
                tradeSellGoodsHandler(data);
            } else if (data.type === "tradeBuyFreight") {
                tradeBuyFreightHandler(data);
            } else if (data.type === "tradeSellFreight") {
                tradeSellFreightHandler(data);
            } else if (data.type === "tradeEmbarkPassenger") {
                tradeEmbarkPassengerHandler(data);
            } else if (data.type === "tradeDisembarkPassenger") {
                tradeDisembarkPassengerHandler(data);
            } else if (data.type === "worldDropBroker") {
                worldDropBrokerHandler(data);
            } else if (data.type === "launchSwarm") {
                launchSwarmHandler(data);
            }
        }
    });

  // Preload Handlebars templates.
  return preloadHandlebarsTemplates();
});

Hooks.once("init", function() {
    // https://github.com/fpiechowski/inline-macro-execution
    const rgx = /\[\[(\/mgMacro)\s*(?:"([^"]*)"|(\S+))\s*(.*?)\s*(]{2,3})(?:{([^}]+)})?/gi;
    CONFIG.TextEditor.enrichers.push({
        pattern: rgx,
        enricher: Tools.macroExecutionEnricher,
    });
    const rgx2 = /\[\[(\/mgt2e)\s*(?:"([^"]*)"|(\S+))\s*(.*?)\s*(]{2,3})(?:{([^}]+)})?/gi;
    CONFIG.TextEditor.enrichers.push({
        pattern: rgx2,
        enricher: Tools.macroExecutionEnricher,
    });
    const rgx3 = /\[\[(\/actor)\s*(?:"([^"]*)"|(\S+))\s*(.*?)\s*(]{2,3})(?:{([^}]+)})?/gi;
    CONFIG.TextEditor.enrichers.push({
        pattern: rgx3,
        enricher: Tools.macroExecutionEnricher,
    });
    const rgx4 = /\[\[(\/item)\s*(?:"([^"]*)"|(\S+))\s*(.*?)\s*(]{2,3})(?:{([^}]+)})?/gi;
    CONFIG.TextEditor.enrichers.push({
        pattern: rgx4,
        enricher: Tools.macroExecutionEnricher,
    });
    const rgx5 = /\[\[(\/upp)\s*(?:"([^"]*)"|(\S+))\s*(.*?)\s*(]{2,3})(?:{([^}]+)})?/gi;
    CONFIG.TextEditor.enrichers.push({
        pattern: rgx5,
        enricher: Tools.macroExecutionEnricher,
    });

    const body = $("body");
    body.on("click", "a.inline-macro-execution", Tools.macroClick);
    body.on("click", "a.inline-mgt2e-execution", Tools.mgt2eClick);
    body.on("click", ".actor-link", ev =>  {
       const actorId = $(ev.currentTarget).data("actorId");
       openActorSheet(actorId);
    });
    body.on("click", ".upp-inline-roll", ev => {
        console.log("INLINE ROLL");
        let name = $(ev.currentTarget).data("actorName");
        console.log($(ev.currentTarget).data("skillData"));
        let data = $(ev.currentTarget).data("skillData");
        Tools.inlineUppRollSkill(name, data);
    })

    CONFIG.statusEffects.push({
        id: "destroyed",
        name: "EFFECT.Destroyed",
        img: "systems/mgt2e/icons/effects/destroyed.svg"
    });
    CONFIG.statusEffects.push({
        id: "injured",
        name: "EFFECT.Injured",
        img: "systems/mgt2e/icons/effects/injured.svg"
    });
    CONFIG.statusEffects.push({
        id: "needsFirstAid",
        name: "EFFECT.FirstAid",
        img: "systems/mgt2e/icons/effects/firstaid.svg"
    });
    CONFIG.statusEffects.push({
        id: "needsSurgery",
        name: "EFFECT.Surgery",
        img: "systems/mgt2e/icons/effects/surgery.svg"
    });
    CONFIG.statusEffects.push({
        id: "encumbered",
        name: "EFFECT.Encumbered",
        img: "systems/mgt2e/icons/effects/encumbered.svg"
    });
    CONFIG.statusEffects.push({
        id: "vaccSuit",
        name: "EFFECT.VaccSuit",
        img: "systems/mgt2e/icons/effects/vaccsuit.svg"
    });
    CONFIG.statusEffects.push({
        id: "surprised",
        name: "EFFECT.Surprised",
        img: "systems/mgt2e/icons/effects/surprised.svg"
    });
    CONFIG.statusEffects.push({
        id: "aware",
        name: "EFFECT.Aware",
        img: "systems/mgt2e/icons/effects/aware.svg"
    });
    CONFIG.statusEffects.push({
        id: "reaction",
        name: "EFFECT.Reaction",
        img: "systems/mgt2e/icons/effects/reaction.svg"
    });
    CONFIG.statusEffects.push({
        id: "fatigued",
        name: "EFFECT.Fatigued",
        img: "systems/mgt2e/icons/effects/fatigued.svg"
    });
    CONFIG.statusEffects.push({
        id: "physical",
        name: "EFFECT.Physical",
        img: "systems/mgt2e/icons/effects/physical.svg"
    });
    CONFIG.statusEffects.push({
        id: "melee",
        name: "EFFECT.Melee",
        img: "systems/mgt2e/icons/effects/melee.svg"
    });
    CONFIG.statusEffects.push({
        id: "gunCombat",
        name: "EFFECT.GunCombat",
        img: "systems/mgt2e/icons/effects/guncombat.svg"
    });
    CONFIG.statusEffects.push({
        id: "armour",
        name: "EFFECT.Armour",
        img: "systems/mgt2e/icons/effects/armour.svg"
    });
    CONFIG.statusEffects.push({
        id: "inCover",
        name: "EFFECT.InCover",
        img: "systems/mgt2e/icons/effects/inCover.svg"
    });
    CONFIG.statusEffects.push({
        id: "hiding",
        name: "EFFECT.Hiding",
        img: "systems/mgt2e/icons/effects/hiding.svg"
    });
    CONFIG.statusEffects.push({
        id: "stunned",
        name: "EFFECT.Stunned",
        img: "icons/svg/daze.svg"
    });
    CONFIG.statusEffects.push({
        id: "tactics",
        name: "EFFECT.Tactics",
        img: "systems/mgt2e/icons/effects/tactics.svg"
    });
    CONFIG.statusEffects.push({
        id: "initiative",
        name: "EFFECT.Initiative",
        img: "systems/mgt2e/icons/effects/initiative.svg"
    });
})

async function openActorSheet(actorId) {
    let actor = await fromUuid(actorId);
    if (actor) {
        actor.sheet.render(true);
    } else {
        ui.notifications.error(`Actor [${actorId}] cannot be found`);
    }
}

Hooks.on('renderChatMessageHTML', function(message, html, data) {
    // Allow actor links to be opened from chat messages.
    const actorLink = html.querySelector(".actor-uuid-link");
    if (actorLink) {
        actorLink.onclick = () => {
            const actorUuid = actorLink.getAttribute("data-actor-id");
            fromUuid(actorUuid).then(actor => {
                actor.sheet.render(true);
            });
        }
    }
    const itemLink = html.querySelector(".item-uuid-link");
    if (itemLink) {
        itemLink.onclick = () => {
            const itemUuid = itemLink.getAttribute("data-item-id");
            fromUuid(itemUuid).then(item => {
                item.sheet.render(true);
            });
        }
    }

    const damageMessage = html.querySelector(".damage-message");
    if (damageMessage) {
        damageMessage.setAttribute("draggable", true);
        let dragData = {
            type: "Damage",
            laser: false,
            ap: parseInt(damageMessage.getAttribute("data-ap")),
            damage: parseInt(damageMessage.getAttribute("data-damage")),
            traits: damageMessage.getAttribute("data-traits"),
            vers: damageMessage.getAttribute("data-vers"),
            options: damageMessage.getAttribute("data-options"),
            tl: parseInt(damageMessage.getAttribute("data-tl"))
        }
        damageMessage.addEventListener("dragstart", ev => {
            return ev.dataTransfer.setData("text/plain", JSON.stringify(dragData));
        });
    }

    const skillMessage = html.querySelector(".skillcheck-message");
    if (skillMessage) {
        skillMessage.setAttribute("draggable", true);
        let dragData = {
            type: "Skill",
            skill: skillMessage.getAttribute("data-skillcheck"),
            options: skillMessage.getAttribute("data-options")
        };
        skillMessage.addEventListener("dragstart", ev => {
            return ev.dataTransfer.setData("text/plain", JSON.stringify(dragData));
        });
    }

    const uppMessage = html.querySelector(".upp-data");
    if (uppMessage) {
        uppMessage.setAttribute("draggable", true);
        let dragData = {
            type: "UPP",
            STR: parseInt(uppMessage.getAttribute("data-STR")),
            DEX: parseInt(uppMessage.getAttribute("data-DEX")),
            END: parseInt(uppMessage.getAttribute("data-END")),
            INT: parseInt(uppMessage.getAttribute("data-INT")),
            EDU: parseInt(uppMessage.getAttribute("data-EDU")),
            SOC: parseInt(uppMessage.getAttribute("data-SOC"))
        }
        uppMessage.addEventListener("dragstart", ev => {
            return ev.dataTransfer.setData("text/plain", JSON.stringify(dragData));
        });
    }

    const skillGainLinks = html.querySelectorAll(".skillGain-spec");
    skillGainLinks.forEach((link, i) => {
        link.addEventListener("click", ev => {
            let actorId = link.getAttribute("data-actorId");
            let skill = link.getAttribute("data-skill");
            let level = link.getAttribute("data-level");
            MgT2eMacros.specialityGain(actorId, skill, level);
        });
    });
});

Hooks.on('ready', () => {
    if (game.user.isGM) {
        // Do we need to run a migration?
        const LATEST_SCHEMA_VERSION = 10;
        const currentVersion = parseInt(game.settings.get("mgt2e", "systemSchemaVersion"));
        console.log(`Schema version is ${currentVersion}`);
        if (!currentVersion || currentVersion < LATEST_SCHEMA_VERSION) {
            migrateWorld(currentVersion);
            game.settings.set("mgt2e", "systemSchemaVersion", LATEST_SCHEMA_VERSION);
        }
    }
    // Need to add click event to all existing chat damage buttons.
    $(document).on('click', '.damage-button', function() {
       let dmg = $(this).data('damage');
       let damageOptions = $(this).data("options");

       Tools.applyDamageToTokens(dmg, damageOptions);
    });
    $(document).on('click', '.damage-roll-button', function() {
        let damageOptions = $(this).data("options");

        Tools.rollSplitDamage(damageOptions);
    });
    $(document).on('click', '.skillcheck-button', function() {
        let skillFqn = $(this).data('skillcheck');
        let skillOptions = $(this).data("options");

        Tools.requestedSkillCheck(skillFqn, skillOptions);
    });

});

Hooks.on("chatMessage", function(chatlog, message, chatData) {
    let msg = message;
    if (parseInt(game.version) > 13) {
        // Chat message is HTML in 14+
        const doc = new DOMParser().parseFromString(message, "text/html");
        msg = doc.body.textContent.trim() || "";
    }
    if (msg.indexOf("/upp") === 0) {
        let args = msg.split(" ");
        args.shift();
        Tools.upp(chatData, args);
        return false;
    } else if (msg.indexOf("/damage") === 0) {
        let args = msg.split(" ");
        args.shift();
        Tools.damage(chatData, args);
        return false;
    } else if (msg.indexOf("/skills") === 0) {
        let args = msg.split(" ");
        args.shift();
        Tools.showSkills(chatData, args);
        return false;
    } else if (msg.indexOf("/time") === 0) {
        let args = msg.split(" ");
        args.shift();
        Tools.currentTime(chatData, args);
        return false;
    } else if (msg.indexOf("/debug") === 0) {
        Tools.debugSelected(chatData);
        return false;
    } else if (msg.indexOf("/skill") === 0) {
        let args = msg.split(" ");
        args.shift();
        Tools.rollChatSkill(chatData, args);
        return false;
    } else if (msg.indexOf("/mgt2e-test") === 0) {
        let args = msg.split(" ");
        args.shift();
        Tools.test(chatData,args);
        return false;
    }

    return true;
});

Hooks.on("createItem", (item) => {
    if (item.img === "icons/svg/item-bag.svg") {
        if (item.type === "weapon") {
            item.img = "systems/mgt2e/icons/items/gun-slug.svg";
        } else if (item.type === "armour") {
            item.img = "systems/mgt2e/icons/items/armour-light.svg";
        } else if (item.type === "augment") {
            item.img = "systems/mgt2e/icons/items/cybernetic.svg";
        } else if (item.type === "cargo") {
            item.img = "systems/mgt2e/icons/cargo/cargo.svg";
        } else if (item.type === "term") {
            item.img = "systems/mgt2e/icons/misc/career.svg";
        } else if (item.type === "role") {
            item.img = "systems/mgt2e/icons/items/crew_role.svg";
        } else if (item.type === "software") {
            item.img = "systems/mgt2e/icons/items/software.svg";
        } else if (item.type === "option") {
            item.img = "systems/mgt2e/icons/items/option.svg";
        } else {
            item.img = "systems/mgt2e/icons/items/item.svg";
        }
        item.safeUpdate({ "img": item.img });
    }
});



/**
 * Fired after actor has been created from data in template.json.
 * We need to fill in from CONFIG structures. We need to do it this
 * way since V12, since we can't access the template.json in V12.
 */
Hooks.on("createActor", (actor, data, userId) => {
    if (!game.users.current.isGM) {
        let player = game.users.current;
        if (game.user._id === userId && actor.type === "traveller") {
            let playerName = player.name;
            if (player.character === null && game.settings.get("mgt2e", "autoPlayerCharacter")) {
                player.update({"character": actor._id});
            }
            // If we don't do both of the following, player name isn't set
            // after updating the default character.
            actor.system.player = playerName;
            actor.update({"system.player": playerName});
        } else {
            return;
        }
    }

    if (actor.type === "traveller" && game.settings.get("mgt2e", "visionDefaultTraveller")) {
        actor.update({"prototypeToken.sight.enabled": true});
    } else if (actor.type === "npc" && game.settings.get("mgt2e", "visionDefaultNPC")) {
        actor.update({"prototypeToken.sight.enabled": true});
    } else if (actor.type === "creature" && game.settings.get("mgt2e", "visionDefaultCreature")) {
        actor.update({"prototypeToken.sight.enabled": true});
    } else if ((actor.type === "spacecraft" || actor.type === "vehicle") && game.settings.get("mgt2e", "visionDefaultSpacecraft")) {
        actor.update({"prototypeToken.sight.enabled": true});
    } else if (actor.type === "npc" && game.settings.get("mgt2e", "npcChaDamage")) {
        actor.addDamageValues();
    }

    if (["traveller", "world"].includes(actor.type)) {
        actor.update({"prototypeToken.actorLink": true});
    }

    // Copy in characteristics where needed.
    if (["traveller", "npc", "package", "robot"].includes(actor.type)) {
        // Need to add characteristics. We want them in a specific order, otherwise
        // they get sorted alphabetically.
        for (let c of [
            "STR", "DEX", "END", "INT", "EDU", "SOC",
            "CHA", "TER", "PSI", "WLT", "LCK", "MRL",
            "STY", "RES", "FOL", "REP" ]) {

            if (actor.system.characteristics[c]) {
                continue;
            }
            actor.system.characteristics[c] = JSON.parse(
                JSON.stringify(MGT2.CHARACTERISTICS[c])
            );
            if (actor.type === "package") {
                actor.system.characteristics[c].value = 0;
                actor.system.characteristics[c].current = 0;
            }
        }
        actor.update({ "system.characteristics": actor.system.characteristics });
    }

    // Copy in skills where needed.
    const BASE_SKILLS = MGT2.getDefaultSkills();
    if (["traveller", "npc", "package", "creature", "robot"].includes(actor.type)) {
        // Need to add skills.
        for (let s in BASE_SKILLS) {
            if (actor.system.skills[s]) {
                continue;
            }
            actor.system.skills[s] = JSON.parse(
                JSON.stringify(BASE_SKILLS[s])
            )
            actor.system.skills[s].id = s;
            actor.system.skills[s].value = 0;
            if (actor.system.skills[s].specialities) {
                for (let sp in actor.system.skills[s].specialities) {
                    actor.system.skills[s].specialities[sp].id = sp;
                    actor.system.skills[s].specialities[sp].value = 0;
                }
            }
            if (!actor.system.skills[s].icon) {
                actor.system.skills[s].icon = `systems/mgt2e/icons/skills/${s}.svg`;
            }
        }
        actor.update({ "system.skills": actor.system.skills });
    }

    if (actor.img === "icons/svg/mystery-man.svg") {
        let colours = [ "white", "blue", "gold", "green", "red" ];
        if (actor.type === "creature") {
            actor.img = `systems/mgt2e/icons/actors/creature-${colours[colours.length * Math.random() | 0]}.svg`;
        } else if (actor.type === "traveller" || actor.type === "npc") {
            actor.img = `systems/mgt2e/icons/actors/traveller-${colours[colours.length * Math.random() | 0]}.svg`;
        } else if (actor.type === "package") {
            actor.img = `systems/mgt2e/icons/actors/traveller-grey.svg`;
        } else if (actor.type === "robot") {
            actor.img = `systems/mgt2e/icons/actors/robot.svg`;
        } else if (actor.type === "spacecraft") {
            actor.img = `systems/mgt2e/images/tokens/spacecraft/white/far_trader.webp`;
        } else if (actor.type === "vehicle") {
            actor.img = `systems/mgt2e/images/tokens/vehicles/white/jeep.webp`;
        } else if (actor.type === "swarm") {
            let colours = [ "white", "grey", "gold", "blue", "red", "green" ];
            let c = colours[colours.length * Math.random() | 0];
            actor.img = `systems/mgt2e/icons/actors/squadron-${c}.svg`;
        } else if (actor.type === "world") {
            actor.img = `systems/mgt2e/icons/actors/world.svg`;
        } else {
            actor.img = "systems/mgt2e/icons/actors/traveller-red.svg";
        }
        actor.update({ "img": actor.img });
    }
    if (actor.type === "npc") {
        actor.update({"system.settings.columns": 6 });
    }
});

Hooks.on("preUpdateActor2", (actor, changedData, options, userId) => {
    if (game.user.id !== userId) return;
    console.log("preUpdateActor");
    if (foundry.utils.getProperty(changedData, "system.damage")) {
        // The damage applied by the update.
        const damage = foundry.utils.getProperty(changedData, "system.damage");
        console.log(damage);
        let endDmg = parseInt(damage.END?damage.END.value:0);
        let strDmg = parseInt(damage.STR?damage.STR.value:0);
        let dexDmg = parseInt(damage.DEX?damage.DEX.value:0);

        // The damage before the update.
        const currentDamage = actor.system.damage;
        console.log(currentDamage);
        let endCur = parseInt(currentDamage.END.value);
        let strCur = parseInt(currentDamage.STR.value);
        let dexCur = parseInt(currentDamage.DEX.value);

        let endMax = actor.system.characteristics.END.value;
        let strMax = actor.system.characteristics.STR.value;
        let dexMax = actor.system.characteristics.DEX.value;

        // How much damage was actually done in this attack?
        let totalDamage = (endDmg - endCur) + (strDmg - strCur) + (dexDmg - dexCur);

        console.log(`Damage is STR ${strCur} DEX ${dexCur} END ${endCur}`);
        console.log(`Damage is STR ${strDmg} DEX ${dexDmg} END ${endDmg} TOTAL ${totalDamage}`);

        let atZero = 0;
        if (endDmg >= endMax) atZero++;
        if (dexDmg >= dexMax) atZero++;
        if (strDmg >= strMax) atZero++;
        switch (atZero) {
            case 2:
                actor.setFlag("mgt2e", "unconscious", true);
                actor.unsetFlag("mgt2e", "disabled");
                actor.unsetFlag("mgt2e", "dead");
                break;
            case 3:
                actor.setFlag("mgt2e", "disabled", true);
                break;
            default:
                actor.unsetFlag("mgt2e", "unconscious");
                actor.unsetFlag("mgt2e", "disabled");
                actor.unsetFlag("mgt2e", "dead");
        }
    } else if (changedData?.system?.hits) {
        console.log("NPC OR CREATURE");
        // This is an NPC or Creature
        const hits = foundry.utils.getProperty(changedData, "system.hits");
        let dmg = hits.damage?hits.damage:actor.system.hits.damage;
        let max = hits.max?hits.max:actor.system.hits.max;

        if (dmg >= max) {
            actor.setFlag("mgt2e", "dead", "true");
            actor.unsetFlag("mgt2e", "unconscious");
            actor.unsetFlag("mgt2e", "disabled");
        } else if (dmg >= max * 0.667) {
            actor.setFlag("mgt2e", "unconscious", "true");
            actor.unsetFlag("mgt2e", "dead");
            actor.unsetFlag("mgt2e", "disabled");
        } else {
            actor.unsetFlag("mgt2e", "unconscious");
            actor.unsetFlag("mgt2e", "disabled");
            actor.unsetFlag("mgt2e", "dead");
        }
    }
});

Hooks.on("updateActor", async (actor, updateData, options, userId) => {
   if (game.user._id !== userId) return;

    if (foundry.utils.getProperty(updateData, "system.damage")) {
       if (actor.system.characteristics) {
           let char = actor.system.characteristics;
           let str = Number(char['STR'].current);
           let dex = Number(char['DEX'].current);
           let end = Number(char['END'].current);

           let numAtZero = 0;
           if (str < 1) numAtZero++;
           if (dex < 1) numAtZero++;
           if (end < 1) numAtZero++;

           switch (numAtZero) {
               case 2:
                   actor.setUnconsciousEffect(true);
                   break;
               case 3:
                   actor.setDeadEffect(true);
                   actor.setUnconsciousEffect(false);
                   break;
           }
       }
    } else if (foundry.utils.getProperty(updateData, "system.hits")) {
        if (["npc", "creature"].includes(actor.type)) {
            let hits = Number(actor.system.hits.value);
            let max = Number(actor.system.hits.max);

            if (hits > max/2) {
                // No effects.
            } else if (hits > max/10) {
                actor.setInjuredEffect(true);
            } else if (hits > 0) {
                actor.setUnconsciousEffect(true);
                actor.setInjuredEffect(true);
            } else {
                actor.setDeadEffect(true);
                actor.setUnconsciousEffect(false);
                actor.setInjuredEffect(false);
            }
        } else if (["spacecraft"].includes(actor.type)) {
            let hits = Number(actor.system.hits.value);
            if (hits < 1) {
                actor.setDestroyedEffect(true);
            }
        }
    }
});

Hooks.on("hotbarDrop", (bar, data, slot) => {
    if (data.type === "Actor" || data.type === "Item" || data.data?.dragType === "skill") {
        createTravellerMacro(data, slot);
        return false;
    } else {
        console.log(data);
        return true;
    }
});

Hooks.once("ready", async function() {
    if (game.user.isGM) {
        if (game.scenes.size === 0) {
            const pack = game.packs.get("mgt2e.base-scenes");
            if (pack) {
                const entry = await pack.getIndex();
                const sceneId = entry?.find(e => e.name === "MgT2e")?._id;
                if (sceneId) {
                    const scene = await game.scenes.importFromCompendium(pack, sceneId);
                    if (scene) {
                        await scene.activate();
                    }
                }
            }
        }
    }
});


Hooks.on("createCombatant", (combatant, combat, id) => {
   if (!game.user.isGM) {
       return;
   }
    console.log("createCombatant:");
    const actor = combatant.actor;

    let bonus = 0;
   if (actor.getEffect("surprised")) {
       bonus = -6;
   } else if (actor.getEffect("aware")) {
       bonus = +6;
   }
   actor.getRollData();
   const roll = new Roll(`2D6 - 8 + @initiative.value + ${bonus}`, actor.getRollData());
   roll.evaluate().then(rolledInstance => {
       combatant.initiative = rolledInstance.total;
       combatant.update({"initiative": combatant.initiative});
   });

});

Hooks.on("combatTurn", (combat, data, options) => {
    // This is the actor which just finished their turn.
    let actor = combat.combatant.actor;
    // Reset any reaction penalties back to zero.
    actor.setReactionEffect(0);

    // If stunned, reduce rounds left to be stunned
    const stunned = actor.getEffect("stunned");
    if (stunned) {
        let rounds = stunned.getFlag("mgt2e", "value");
        if (--rounds > 0) {
            stunned.setFlag("mgt2e", "value", rounds);
        } else {
            actor.setStunnedEffect(0);
        }
    }
});

Hooks.on("combatRound", (combat, data, options) => {
    // This is when the round changes.
    for (let combatant of combat.combatants) {
        const actor = combatant.actor;
        if (actor.getEffect("surprised")) {
            actor.setSurprisedEffect(false);
            combatant.update({"initiative": combatant.initiative + 6 });
        } else if (actor.getEffect("aware")) {
            actor.setAwareEffect(false);
            combatant.update({"initiative": combatant.initiative - 6 });
        }
    }

    let combatant = combat.combatant.actor;

    // If stunned, reduce rounds left to be stunned
    let stunnedEffect = combatant.effects.find(e => e.statuses?.values()?.next()?.value === "stun");
    if (stunnedEffect) {
        if (!isNaN(parseInt(stunnedEffect.flags?.mgt2e?.value))) {
            let rounds = parseInt(stunnedEffect.flags.mgt2e.value);
            if (rounds > 1) {
                rounds -= 1;
                stunnedEffect.setFlag("mgt2e", "value", rounds);
            } else {
                stunnedEffect.delete();
            }
        }
    }
});

Hooks.on("dropCanvasData", (canvas, data) =>{
    if (data && data.type === "Damage") {
        // Are we dropping a blast effect on the scene?
        const options = JSON.parse(data.options);
        if (options.blastRadius) {
            Tools.showBlastRadius(data.x, data.y, options);
        }
    }
});


// Dropping a skill on the macro bar. An entire skill tree is dragged,
// not just a speciality.
async function createTravellerMacro(data, slot) {
    let actorId = data.actorId;
    let dragData = data.data;

    if (data.type === "Item") {
        let item = await Item.fromDropData(data);
        let label = item.name;

        let command = null;
        if (item.type === "weapon") {
            command = `game.mgt2e.rollAttackMacro('${item.name}')`;
        } else {
            command = `Hotbar.toggleDocumentSheet("${item.uuid}")`;
        }

        if (command) {
            let macro = await Macro.create({
                name: label,
                type: "script",
                command: command,
                img: item.img
            });
            game.user.assignHotbarMacro(macro, slot);
        } else {
            ui.notifications.warn(`Don't know what to do with "${label}"`);
        }
        return false;
    } else if (data.type === "Actor") {
        let actor = await Actor.fromDropData(data);
        if (actor) {
            let label = actor.name;
            let command = `Hotbar.toggleDocumentSheet("${actor.uuid}")`;

            let macro = await Macro.create({
                name: label,
                type: "script",
                command: command,
                img: actor.img
            });
            game.user.assignHotbarMacro(macro, slot);
        }
    } else if (dragData.dragType === "skill") {
        let actor = game.actors.find(a => (a._id === actorId));
        if (!actor) {
            ui.notifications.warn(game.i18n.localize("MGT2.Warn.HotBar.NewActor"));
            return false;
        }
        let label = actor.getSkillLabel(dragData.skillName);

        const command = `game.mgt2e.rollSkillMacro('${dragData.skillName}')`;
        let macro = null;
        if (!macro) {
            macro = await Macro.create({
                name: label,
                type: "script",
                command: command,
                img: actor.getSkillIcon(dragData.skillName)
            });
        }
        ui.notifications.info(game.i18n.format("MGT2.Info.HotBar.AssignedSkill", { skill: label}));
        game.user.assignHotbarMacro(macro, slot);
        return false;
    }

}

function rollSkillMacro(skillName, options) {
  console.log("rollSkillMacro: " + skillName);

  if (!options) {
      options = {};
  }

  if (options.agent) {
      new MgT2SkillDialog(null, skillName, options).render(true);
      return;
  }

  const speaker = ChatMessage.getSpeaker();
  let actor;
  if (options.actor ) {
      actor = options.actor;
      // Don't want to pass actor object around everywhere
      options.actor = undefined;
  } else {
      if (speaker.token) {
          actor = game.actors.tokens[speaker.token];
      } else if (game.user.character) {
          actor = game.user.character;
      }
      if (!actor) {
          actor = game.actors.get(speaker.actor);
      }
      if (!actor) {
          ui.notifications.warn(game.i18n.localize("MGT2.Warn.HotBar.SelectActorSkill"));
          return;
      }
  }

  if (game.settings.get("mgt2e", "quickRolls") || options.quick) {
      rollSkill(actor, skillName, options);
  } else {
      new MgT2SkillDialog(actor, skillName, options).render(true);
  }
}

function rollAttackMacro(itemName) {
    console.log("rollAttackMacro: ");
    const speaker = ChatMessage.getSpeaker();
    let actor;
    if (speaker.token) {
        actor = game.actors.tokens[speaker.token];
    }
    if (!actor) {
        actor = game.actors.get(speaker.actor);
    }
    if (!actor) {
        return ui.notifications.warn(game.i18n.format("MGT2.Warn.HotBar.SelectActorItem", {item: itemName }));
    }

    let item = actor.items.find(i => (i.name === itemName));
    if (!item) {
        return ui.notifications.warn(game.i18n.format("MGT2.Warn.HotBar.ActorNotHaveItem", {actor: actor.name, item: itemName }));
    }

    new MgT2AttackDialog(actor, item).render(true);
}

function updateData(dmg, ap) {
    console.log("Doing it here");
}

/* -------------------------------------------- */
/*  Handlebars Helpers                          */
/* -------------------------------------------- */

// If you need to add Handlebars helpers, here are a few useful examples:
Handlebars.registerHelper('concat', function() {
    var outStr = '';
    for (var arg in arguments) {
        if (typeof arguments[arg] != 'object') {
            outStr += arguments[arg];
        }
    }
    return outStr;
});

Handlebars.registerHelper('toLowerCase', function(str) {
    return str.toLowerCase();
});

Handlebars.registerHelper('toPlainText', function(html) {
    if (html && typeof html === 'string') {
        let text = html.replace(/<[^>]*>/g, "");

        text = text.replace(/@UUID.*\{(.*)\}/, "$1");
        text = text.replace(/&.*;/, "");
        if (text.length > 120) {
            text = text.substring(0, 117) + "...";
        }
        return text;
    } else {
        return "Undefined";
    }
});

Handlebars.registerHelper('isChaShown', function(data, ch) {
    if (data.characteristics[ch]) {
        return data.characteristics[ch].show;
    } else {
        return false;
    }
});

Handlebars.registerHelper('defaultSkill', function(data) {
    if (data && data.skills && data.skills.jackofalltrades && data.skills.jackofalltrades.trained) {
        let dm = data.skills.jackofalltrades.value - 3;
        return (dm > 0)?0:dm;
    } else {
        return -3;
    }
});

Handlebars.registerHelper('showSpec', function(data, spec) {
    if (spec && spec.value && parseInt(spec.value) > 0) {
        return "inline-block";
    }
    return "hidden";
});


Handlebars.registerHelper('skillLabel', function(data, skill, spec) {
    if (data && data.skills && skill) {
        let cha = skill.default;
        let type = "";

        if (data.settings.rollType === "boon") {
            type = ` [${game.i18n.localize("MGT2.TravellerSheet.Boon")}]`;
        } else if (data.settings.rollType === "bane") {
            type = ` [${game.i18n.localize("MGT2.TravellerSheet.Bane")}]`;
        }

        const chars = data.characteristics;
        for (let ch in chars) {
            if (chars[ch].default) {
                cha = ch;
                break;
            }
        }

        if (skill.trained) {
            if (spec) {
                return `${cha} + ${skillLabel(skill)} (${skillLabel(spec)}) ${type}`;
            } else {
                return `${cha} + ${skillLabel(skill)} ${type}`;
            }
        } else {
            return `${cha} + ${skillLabel(skill)}  (${game.i18n.localize("MGT2.TravellerSheet.Untrained")}) ${type}`;
        }
    } else {
        return "Roll";
    }
});

Handlebars.registerHelper('skillRollable', function(data, skill, spec) {
    if (data && data.skills && skill) {
        let cha = skill.default;
        let dice = "2d6";

        if (data.settings.rollType === "boon") {
            dice="3d6k2";
        } else if (data.settings.rollType === "bane") {
            dice="3d6kl2";
        }

        const chars = data.characteristics;
        for (let ch in chars) {
            if (chars[ch].default) {
                cha = ch;
                break;
            }
        }
        if (skill.trained) {
            let value = skill.value;
            let label = skill.label;
            if (spec) {
                value = spec.value;
                label = spec.label;
            }

            return dice + " + @" + cha + "["+cha+"] + " + value + "[" + label + "]";
        } else {
            let untrained = -3;
            if (data.skills && data.skills.jackofalltrades &&
                data.skills.jackofalltrades.trained) {
                untrained += data.skills.jackofalltrades.value;
            }

            return dice + " + @" + cha + "["+cha+"] + " + untrained + "[untrained]";
        }
    } else {
        return "2d6[Undefined]";
    }
});

Handlebars.registerHelper('rollType', function(data, type) {
    if (type === data.settings.rollType) {
        return "rollTypeActive";
    }
    return "rollType";
});

Handlebars.registerHelper('rollTypeActive', function(data, type) {
    if (type === data.settings.rollType) {
        return "checked";
    }
    return "";
});
Handlebars.registerHelper('isItemGeneral', function(item) {
    if (item.type === "item") {
        return true;
    }
    return false;
});
Handlebars.registerHelper('isItemAugment', function(item) {
    if (item.type === "augment") {
        return true;
    }
    return false;
});

Handlebars.registerHelper('isItemEquipped', function(item) {
    if (item.system.status === MgT2Item.EQUIPPED) {
        return true;
    }
    return false;
});

Handlebars.registerHelper('isItemCarried', function(item) {
    if (item.system.status === MgT2Item.CARRIED) {
        return true;
    }
    return false;
});

Handlebars.registerHelper('isItemOwned', function(item) {
    if (item.system.status === MgT2Item.EQUIPPED || item.system.status === MgT2Item.CARRIED) {
        return false;
    }
    if (item.type === "term" || item.type === "associate") {
        return false;
    }
    return true;
});

Handlebars.registerHelper('isItemPhysical', function(item) {
    if (item.type === "term" || item.type === "associate") {
        return false;
    }
    return true;
});


Handlebars.registerHelper('equipItem', function(item) {
    if (item.system.status === MgT2Item.EQUIPPED || item.system.weight === undefined) {
        return "";
    }

    let title="Activate item";
    let icon="fa-hand-fist";
    if (item.type === "armour") {
        title = "Wear armour";
        icon = "fa-shirt";
    }
    return `<a class="item-control item-activate" title="${title}"><i class="fas ${icon}"></i></a>`;
});

Handlebars.registerHelper('deactivateItem', function(item) {
    if (!item.system.status || item.system.status === MgT2Item.CARRIED || item.system.status === MgT2Item.OWNED || item.system.weight === undefined) {
        return "";
    }

    let title="Deactivate item";
    let icon="fa-suitcase";
    if (item.type === "armour") {
        title = "Remove armour";
    } else if (item.type === "weapon") {
        title = "Put away weapon";
    }
    return `<a class="item-control item-deactivate" title="${title}"><i class="fas ${icon}"></i></a>`;
});

Handlebars.registerHelper('storeItem', function(item) {
    if (!item.system.status || item.system.status === MgT2Item.OWNED || item.system.weight === undefined) {
        return "";
    }
    let title="Store item";
    let icon="fa-arrow-down-to-square";
    return `<a class="item-control item-store" title="${title}"><i class="fas ${icon}"></i></a>`;
});

Handlebars.registerHelper('carryItem', function(item) {
    if (item.system.status === MgT2Item.CARRIED || item.system.weight === undefined) {
        return "";
    }
    let title="Carry item";
    let icon="fa-suitcase";
    return `<a class="item-control item-carry" title="${title}"><i class="fas ${icon}"></i></a>`;
});

Handlebars.registerHelper('cycleItem', function (item) {
    let storeTitle = "Store";
    let storeIcon = "far fa-house";

    let carryTitle = "Carry";
    let carryIcon = "far fa-suitcase";

    let equipTitle = "Equip";
    let equipIcon = "far fa-hand-fist";

    if (item.type === "armour") {
            equipTitle = "Wear";
            equipIcon = "far fa-shirt";
        };
    if (item.type === "weapon") {
            equipIcon = "far fa-gun";
        };
    if (item.type === "augment") {
        equipTitle = "Install";
        equipIcon = "far fa-microchip";
    }

    if (item.system.weight === undefined) {
        return "";
    }
    if (!item.system.status || item.system.status === MgT2Item.OWNED) {
        storeTitle = "Stored";
        storeIcon = "fas fa-house";
    }

    if (item.system.status === MgT2Item.CARRIED) {
        carryTitle = "Carried";
        carryIcon = "fas fa-suitcase";
    }

    if (item.system.status === MgT2Item.EQUIPPED) {
        equipTitle = "Equipped";
        equipIcon = "fas fa-hand-fist";

        if (item.type === "armour") {
            equipTitle = "Worn";
            equipIcon = "fas fa-shirt";
        }
        if (item.type === "weapon") {
            equipTitle = "Held";
            equipIcon = "fas fa-gun";
        }
        if (item.type === "augment") {
        equipTitle = "Installed";
        equipIcon = "fas fa-microchip";
    }

    }
    return `
    <a class="item-control item-activate" title="${equipTitle}"><i class="${equipIcon}"></i></a>
    <a class="item-control item-carry" title="${carryTitle}"><i class="${carryIcon}"></i></a>
    <a class="item-control item-store" title="${storeTitle}"><i class="${storeIcon}"></i></a>
    `;
});
Handlebars.registerHelper('isTrained', function(skill) {
    if (skill) {
        if (skill.trained) {
            return true;
        }
    }
    return false;
});

Handlebars.registerHelper('ifEquals', function() {
    let value = arguments[0];

    for (let i=1; i < arguments.length; i++) {
        if (value === arguments[i]) {
            return true;
        }
    }
    return false;
});

Handlebars.registerHelper('ifStartsWith', function(arg1, arg2) {
    if (arg1 && arg2) {
        return arg1.startsWith(arg2);
    }
    return false;
});

Handlebars.registerHelper('mountedWeaponsCount', function(mount, wpn) {
    if (mount.hardware.weapons) {
        if (mount.hardware.weapons[wpn._id]) {
            let q = parseInt(mount.hardware.weapons[wpn._id].quantity);
            if (q > 1) {
                return "x" + q;
            }
        }
    }
    return "";
});

Handlebars.registerHelper('nameQuantity', function(item, context) {
    let name = item.name;
    let quantity = item.system.quantity;
    let extra = null;

    if (item.type === "role") {
        quantity = item.system.role.positions;
    }

    if (item.type === "hardware") {
        let hardware = item.system.hardware;
        let sys = hardware.system;
        if (sys === "cargo" || sys === "fuel") {
            extra = hardware.rating + "dt";
        } else if (sys === "power" && hardware.rating) {
            extra = "" + hardware.rating;
        } else if (sys === "j-drive" && hardware.rating) {
            extra = "J-" + hardware.rating;
        } else if (sys === "m-drive" && hardware.rating) {
            extra = hardware.rating + "G";
        }
    }

    if (extra) {
        name = `${name} [${extra}]`;
    }

    if (quantity && parseInt(quantity) > 1) {
        if (context === "sidebar") {
            if (item.type === "weapon" && hasTrait(item.system.weapon.traits, "oneUse")) {
                quantity = parseInt(quantity);
                name = `${name} x${quantity}`;
            }
        } else {
            quantity = parseInt(quantity);
            name = `${name} x${quantity}`;
        }
    }
    return name;
});

Handlebars.registerHelper('niceNumber', function(value) {
    return value.toLocaleString("en-GB");
});

Handlebars.registerHelper('quantity', function(item, value) {
    return Intl.NumberFormat("en-GB", { maximumFractionDigits: 2}).format(value * item.system.quantity);
});

Handlebars.registerHelper('formula', function(actor, value) {
    if (value === undefined || value === null || value === "") {
        return "";
    } else if (!isNaN(value)) {
        return value;
    } else if (actor === undefined || actor === null) {
        return "";
    } else {
        let roll = new Roll(value, actor.getRollData()).evaluate({async: false});
        return roll.total;
    }
});

Handlebars.registerHelper('augmentedSkill', function(skill, spec) {
    console.log("augmentedSkill:");
    if (!skill) {
        return "";
    }
    let trained = skill.trained;
    if (skill.individual && spec) {
        trained = spec.trained;
    }
    let html = "";
    let data = spec?spec:skill;

    if (data.augment && trained && parseInt(data.augment) > 0) {
        html += `<p class="augmented">Skill Augment +${data.augment}</p>`;
    }
    if (data.expert) {
        html += `<p class="augmented">Expert Software/${data.expert} `;
        if (trained) {
            html += "(+1) ";
        } else {
            html += `[${data.expert - 1}] `;
        }
        html += `EDU/INT max ${data.expert * 2 + 8}</p>`;
    }

    return html;
});

/**
 * Outputs the list of CSS classes to be used by the skill block.
 * Reads the system settings to determine the number of columns to use and
 * whether we are row first or column first.
 */
Handlebars.registerHelper('skillListClasses', function() {
    let classes="skillList";
    let columns = parseInt(game.settings.get("mgt2e", "skillColumns"));
    let format = game.settings.get("mgt2e", "skillFormat");

    if (format === "columns") {
        classes += " skillList-Columns";
        if (columns === 3) {
            classes += " skillList-Columns-Three";
        } else {
            classes += " skillList-Columns-Two";
        }
    } else {
        classes += " skillList-Rows grid";
        if (columns === 3) {
            classes += " skillList-Rows-Three grid-3col";
        } else {
            classes += " skillList-Rows-Two grid-2col";
        }
    }

    return classes;
});

// Decide whether to show a skill or not.
Handlebars.registerHelper('skillBlock', function(data, skillId, skill, key) {
    let showSkill = false;
    let showSpecs = false;
    let trainedOnly = data.settings.hideUntrained;
    let backgroundOnly = data.settings.onlyBackground;
    let untrainedLevel = (data.skills["jackofalltrades"]?.trained)?data.skills["jackofalltrades"].value - 3:-3;
    let isCreature = data.characteristics?false:true;
    let isDeleted = false;

    // Don't show a skill if it requires a characteristic that
    // isn't being used by this actor.
    if (skill.requires && !isCreature) {
        if (!data.characteristics[skill.requires] || !data.characteristics[skill.requires].show) {
            return "";
        }
    }
    if (!skillId && key) {
        // Some old actors might not have an id set on the skill object.
        skillId = Object.keys(data.skills)[key];
        skill.id = skillId;
        skill.icon = skill.icon?skill.icon:`systems/mgt2e/icons/skills/${skillId}.svg`;
    }
    if (!skillId) {
        console.log("Skill has no ID set");
        return "";
    }

    // If backgroundOnly is set, then shortcut to not showing anything.
    if (isCreature && !skill.creature) {
        if (skill.trait && data.traits && data.traits.indexOf(skill.trait) > -1) {
            showSkill = true;
        } else {
            return "";
        }
    } else if (backgroundOnly && !skill.background) {
        return "";
    } else if (backgroundOnly && skill.background) {
        showSkill = true;
    } else if (!trainedOnly || skill.trained) {
        showSkill = true;
    } else {
        if (skill.expert && parseInt(skill.expert) > 0) {
            showSkill = true;
        } else if (skill.dm && parseInt(skill.dm) > 0) {
            showSkill = true;
        } else if (skill.augment && parseInt(skill.augment) > 0) {
            showSkill = true;
        } else if (skill.specialities) {
            for (let sid in skill.specialities) {
                let spec = skill.specialities[sid];
                if (spec.trained) {
                    showSkill = true;
                    break;
                }
                if ((spec.expert && parseInt(spec.expert) > 0) || (spec.dm && parseInt(spec.dm) > 0)) {
                    showSkill = true;
                    break;
                }
            }
        }
    }
    if (showSkill && skill.specialities) {
        for (let sid in skill.specialities) {
            let spec = skill.specialities[sid];
            if ((Number(spec.value) > 0) || (spec.expert && Number(spec.expert) > 0) || (spec.dm && Number(spec.dm) > 0)) {
                showSpecs = true;
                break;
            }
            if (spec.trained) {
                showSpecs = true;
                break;
            }
        }
    }
    if (skill.trained) {
        showSpecs = true;
    }
    if (skill.deleted) {
        isDeleted = true;
    }
    skill.value = parseInt(skill.value);
    if (isNaN(skill.value) || skill.value < 0) {
        skill.value = 0;
    }
    const dataRoll='data-rolltype="skill" data-roll="2d6" data-action="rollCheck"';
    const dataSkill=`data-skill="${skillId}"`;

    const nameSkill=`system.skills.${skillId}`;

    if (showSkill) {
        let html = `<div class="skillBlock skill-draggable item"  ${dataRoll} ${dataSkill}>`;
        html += `<input type="checkbox" class="trained" name="${nameSkill}.trained" `;
        if (skill.trained) {
            html += " checked ";
        }
        html += `data-dtype="Boolean"/> `;
        let augmented = false;

        let title = skill.default;
        if (skill.trained) {
            title += " + " + skill.value;
        } else {
            title += " - " + Math.abs(untrainedLevel);
        }
        if (skill.bonus && Number(skill.bonus) > 0) {
            augmented = true;
        }
        if (skill.expert && Number(skill.expert) > 0) {
            augmented = true;
            title += " /" + (Number(skill.expert) -1);
        }
        if (skill.augment && Number(skill.augment) > 0) {
            augmented = true;
            title += " + " + Number(skill.augment);
        }
        if (skill.augdm && Number(skill.augdm) > 0) {
            augmented = true;
            title += " + " + Number(skill.augdm);
        }
        if (game.settings.get("mgt2e", "quickRolls")) {
            title += "&#10;" + game.i18n.localize("MGT2.TravellerSheet.SkillTitle.Dialog");
        } else {
            title += "&#10;" + game.i18n.localize("MGT2.TravellerSheet.SkillTitle.Quick");
        }
        title += "&#10;"+game.i18n.localize("MGT2.TravellerSheet.SkillTitle.XP");

        let hasXp = (skill.xp && skill.xp > 0);
        let label = skillLabel(skill);
        html += `<label for="system.skills.${skillId}.value" `;
        html += `class="rollable ${skill.trained?"":"untrained"} ${augmented?"augmented":""} ${isDeleted?"deleted":""}" `;
        html += `${dataRoll} ${dataSkill} data-label="${title}" title="${title}"`;
        html += `>${label}${hasXp?"<sup>+</sup>":""}</label>`;

        // Specialities?
        if (!backgroundOnly && skill.specialities && showSpecs) {
            html += `<input type="number" value="${skill.trained?0:untrainedLevel}" data-dtype="Number" class="skill-fixed" readonly/>`;

            let SPECS = [];
            // Sort specialities into alphabetical order according to l10n label.
            for (let sid in skill.specialities) {
                let spec = foundry.utils.deepClone(skill.specialities[sid]);
                spec.id = sid;
                spec.label = skillLabel(spec, sid);
                SPECS.push(spec);
            }
            SPECS = SPECS.sort((a, b) => {
                if (a.label < b.label) {
                    return -1;
                } else {
                    return 1;
                }
            });

            for (let i in SPECS) {
                let sid = SPECS[i].id;
                let spec = SPECS[i];
                spec.value = Number(spec.value);
                if (isNaN(spec.value) || spec.value < 0) {
                    spec.value = 0;
                }
                let showSpec = false;
                if (!trainedOnly && skill.trained) {
                    showSpec = true;
                } else if (Number(spec.value) > 0 && (!skill.individual || spec.trained)) {
                    showSpec = true;
                } else if (spec.expert && Number(spec.expert) > 0) {
                    showSpec = true;
                } else if (spec.trained) {
                    showSpec = true;
                }
                if (showSpec) {
                    let augmented = false;
                    let isDeleted = spec.deleted?true:false;
                    let title = spec.default?spec.default:skill.default;
                    if (skill.trained && !(skill.individual && !spec.trained)) {
                        title += " + " + spec.value;
                    } else {
                        title += " - " + Math.abs(untrainedLevel);
                    }
                    if (spec.expert) {
                        if (isNaN(spec.expert)) {
                            spec.expert = null;
                        } else {
                            spec.expert = parseInt(spec.expert);
                            augmented = true;
                            title += " /" + (spec.expert - 1);
                        }
                    }
                    if (spec.augdm && Number(spec.augdm) > 0) {
                        augmented = true;
                        title += " + " + spec.augdm;
                    }
                    if (spec.augment && Number(spec.augment) > 0) {
                        augmented = true;
                        title += " + " + spec.augment;
                    }
                    if (spec.bonus && Number(spec.bonus) > 0) {
                        augmented = true;
                    }
                    if (game.settings.get("mgt2e", "quickRolls")) {
                        title += "&#10;" + game.i18n.localize("MGT2.TravellerSheet.SkillTitle.Dialog");
                    } else {
                        title += "&#10;" + game.i18n.localize("MGT2.TravellerSheet.SkillTitle.Quick");
                    }
                    title += "&#10;"+game.i18n.localize("MGT2.TravellerSheet.SkillTitle.XP");

                    html += "<div class='specialisationBlock'>";
                    if (skill.individual) {
                        html += `<input type="checkbox" class="spectrained" `;
                        html += `name="${nameSkill}.specialities.${sid}.trained" ${spec.trained?"checked":""} `;
                        html += `data-dtype="Boolean" />`;
                    }
                    let hasXp = (spec.xp && spec.xp > 0);
                    let label = skillLabel(spec);
                    if (spec.optional) {
                        label += " ?";
                    }
                    html += `<label class="${augmented?"augmented":""} ${skill.individual?"individual":""} ${isDeleted?"deleted":""} specialisation rollable" ${dataRoll} ${dataSkill} `;
                    html += `data-spec="${sid}" title="${title}">${label}${hasXp?"<sup>+</sup>":""}</label>`;
                    if (skill.trained && (!skill.individual || spec.trained)) {
                        html += `<input class="skill-level" type="number" name="${nameSkill}.specialities.${sid}.value" value="${spec.value}"/>`;
                    } else {
                        html += `<input type="number" value="${untrainedLevel}" data-dtype="Number" class="skill-fixed" readonly/>`;
                    }
                    html += "</div>";
                }
            }
        } else {
            if (skill.trained) {
                html += `<input class="skill-level" type="number" min="0" max="9" name="${nameSkill}.value" value="${skill.value}" ${dataRoll} ${dataSkill}"/>`;
            } else {
                html += `<input type="number" value="${untrainedLevel}" data-dtype="Number" class="skill-fixed" readonly/>`;
            }
        }

        html += "</div>"; // skillBlock

        return html;
    }

    return "";
});

Handlebars.registerHelper('isOwner', function(key) {
    return key.owner;
});

Handlebars.registerHelper('isObserver', function(key) {
    return key.document.permission >= 2;
});

Handlebars.registerHelper('isLimited', function(key) {
    return key.document.permission >= 2;
});

Handlebars.registerHelper('termYear', function(data, term) {
    if (term < 1) {
        term = 1;
    }

    return 1105;
});

Handlebars.registerHelper('prettyNumber', function(value, precision, sign) {
    if (precision === undefined || precision === null) {
        precision = 1;
    }
    return Tools.prettyNumber(value, precision, sign);
});

/**
 * Given an active effect, display the key in a readable form.
 */
Handlebars.registerHelper('effect', function(key) {
    if (key && key.startsWith("system.characteristics")) {
        key = key.replaceAll(/[a-z.]/g, "");
        return key;
    } else if (key && key.startsWith("system.skills")) {
        let skills = MGT2.getDefaultSkills();
        key = key.replaceAll(/\.[a-z]*$/g, "");
        key = key.replaceAll(/system.skills./g, "");
        let skill = key.replaceAll(/\..*/g, "");
        if (key.indexOf(".specialities") > -1) {
            let spec = key.replaceAll(/.*\./g, "");
            return `${skillLabel(skills[skill], skill)} (${skillLabel(skills[skill].specialities[spec], spec)})`;
        } else {
            return skillLabel(skills[skill], skill);
        }
    } else if (key && key.startsWith("system.modifiers")) {
        if (key === "system.modifiers.encumbrance.multiplierBonus") {
            return "Encumbrance Multiplier"
        }
        key = key.replaceAll(/system\.modifiers\./g, "");
        key = key.replaceAll(/\.effect/g, "");
        return key
    }
    return key;
});

/**
 * Do we need to display the list of status effects for this actor?
 * Does not check to see if a traveller, npc or creature.
 */
Handlebars.registerHelper('hasStatus', function(actor) {

    for (let e of actor.effects) {
        if (e.flags?.mgt2e?.effect) {
            return true;
        }
        return true;
    }
    const status = actor.flags.mgt2e;
    if (!status) return false;

    if (status.fatigued || status.stunned || status.encumbered || status.vaccSuit ||
        status.lowGravity || status.highGravity || status.zeroGravity ||
        status.diseased || status.poisoned || status.dead || status.unconscious ||
        status.disabled || status.reaction || status.needsFirstAid || status.needsSurgery ||
        status.inCover || status.prone) {
        return true;
    }
    return false;
});

Handlebars.registerHelper('itemHasStatus', function(item) {
    const status = item.flags.mgt2e;
    if (!status) return false;

    if (status.damaged || status.destroyed) {
        return true;
    }

    return false;
});

Handlebars.registerHelper('toHex', function(value) {
    return Tools.toHex(value);
});

Handlebars.registerHelper('showStatus', function(actor, status, effect) {
    let type = "statusWarn";
    let label = game.i18n.localize("MGT2.TravellerSheet.StatusLabel."+status);

    // If this is a proper status effect, then we can use a generic solution
    // and skip everything else.
    if (effect && effect?.flags?.mgt2e) {
        let statusEffect = CONFIG.statusEffects.find(e => e.id === status);
        if (statusEffect) {
            label = game.i18n.localize(statusEffect.name);
            type = effect.flags.mgt2e.css;
            let value = null;

            if (!isNaN(parseInt(effect.flags.mgt2e.value))) {
                value = parseInt(effect.flags.mgt2e.value);
                label += ` (${parseInt(effect.flags.mgt2e.value)})`;
            }
            if (!effect.flags.mgt2e.locked) {
                const statusName = "status" + status.charAt(0).toUpperCase() + status.slice(1);
                label += ` <i class="fas fa-xmark effect-remove ${statusName}"> </i>`;
                if (value !== null) {
                    label = `<i class="fas fa-minus effect-minus"> </i> ` +
                            `<i class="fas fa-plus effect-plus"> </i> ` +
                            label;
                }
            }
            return `<div class="resource flex-group-center ${type}"><label class="mgt2e-effect" data-status-id="${status}">${label}</label></div>`;
        } else {
            return "";
        }
    } else if (effect && effect.statuses) {
        // This isn't a status we've added. It's been manually added.
        let text = "";
        for (let s of effect.statuses) {
            let statusEffect = CONFIG.statusEffects.find(e => e.id === s);
            if (statusEffect) {
                label = game.i18n.localize(statusEffect.name);
                text += `<div class="resource flex-group-center ${type}"><label>${label}</label></div>`;
            }
        }
        return text;
    } else if (!status) {
        return "";
    }

    if (status === "fatigued") {
        label += ` <i class="fas fa-xmark statusFatigued"> </i>`;
    } else if (status === "stunned") {
        if (parseInt(actor.getFlag("mgt2e", "stunnedRounds")) > 0) {
            label += ` (${actor.getFlag("mgt2e", "stunnedRounds")})`;
        }
        label += ` <i class="fas fa-xmark statusStunned"> </i>`;
        type = "statusBad";
    } else if (status === "dead") {
        label += ` <i class="fas fa-xmark statusDead"> </i>`;
        type = "statusBad";
    } else if (status === "unconscious") {
        type = "statusBad";
        label += ` <i class="fas fa-xmark statusUnconscious"> </i>`;
    } else if (status === "disabled") {
        label += ` <i class="fas fa-xmark statusDisabled"> </i>`;
        type = "statusBad";
    } else if (status === "reaction") {
        if (!(parseInt(actor.getFlag("mgt2e", "reaction")) < 0)) {
            return "";
        }
        label += ` (${actor.getFlag("mgt2e", "reaction")})`;
        label += ` <i class="fas fa-xmark statusReaction"> </i>`;
    } else if (status === "highGravity") {
        label += ` <i class="fas fa-xmark statusHighGravity"> </i>`;
    } else if (status === "lowGravity") {
        label += ` <i class="fas fa-xmark statusLowGravity"> </i>`;
    } else if (status === "zeroGravity") {
        label += ` <i class="fas fa-xmark statusZeroGravity"> </i>`;
    } else if (status === "diseased") {
        label += ` <i class="fas fa-xmark statusDiseased"> </i>`;
    } else if (status === "poisoned") {
        label += ` <i class="fas fa-xmark statusPoisoned"> </i>`;
    } else if (status === "disabled") {
        type = "statusBad";
        label += ` <i class="fas fa-xmark statusPoisoned"> </i>`;
    } else if (status === "dead") {
        type = "statusBad";
        label += ` <i class="fas fa-xmark statusPoisoned"> </i>`;
    } else if (status === "needsFirstAid") {
        label += ` <i class="fas fa-xmark statusNeedsFirstAid"> </i>`;
    } else if (status === "needsSurgery") {
        type = "statusBad";
        label += ` <i class="fas fa-xmark statusNeedsSurgery"> </i>`;
    } else if (status === "prone") {
        type = "statusGood";
        label += ` <i class="fas fa-xmark statusProne"> </i>`;
    } else if (status === "inCover") {
        type = "statusGood";
        if (parseInt(actor.getFlag("mgt2e", "inCover")) > 0) {
            label += ` (${actor.getFlag("mgt2e", "inCover")})`;
        }
        label += ` <i class="fas fa-xmark statusInCover"> </i>`;
    }

    return `<div class="resource flex-group-center ${type}"><label>${label}</label></div>`;
});

Handlebars.registerHelper('showItemStatus', function(item, status) {
    let type = "statusWarn";
    let label = game.i18n.localize("MGT2.TravellerSheet.StatusLabel."+status);

    console.log(item);

    if (status === "damaged") {
        label += ` <i class="fas fa-xmark damaged"> </i>`;
        if (parseInt(item.getFlag("mgt2e", "damaged")) !== 0) {
            label += ` (${item.getFlag("mgt2e", "damaged")})`;
        }
    } else if (status === "destroyed") {
        label += ` <i class="fas fa-xmark statusDestroyed"> </i>`;
        type = "statusBad";
    }

    return `<div class="resource flex-group-center ${type}"><label>${label}</label></div>`;
});


Handlebars.registerHelper('showCriticals', function(actor) {
    let html = "";

    for (let d in MGT2.SPACECRAFT_DAMAGE) {
        if (actor.flags.mgt2e["damage_" + d]) {
            let label = game.i18n.localize("MGT2.Spacecraft.CriticalLabel."+d);
            let value = actor.flags.mgt2e["damage_" + d];
            if (!isNaN(parseInt(value)) && parseInt(value) !== 0) {
                value = " (" + parseInt(value) + ")";
            } else {
                value = " (" + value + ")";
            }
            label += `${value} <i class="fas fa-xmark critEffDel"> </i>`;
            html += `<div class="resource critical criticalEffect" data-id="${d}"><label>${label}</label></div>`;
        }
    }

    for (let c in MGT2.SPACECRAFT_CRITICALS) {
        let severity = actor.flags.mgt2e["crit_"+c];
        if (severity) {
            let type = "criticalLow";
            if (severity > 4) {
                type = "criticalHigh";
            } else if (severity > 2) {
                type = "criticalMedium";
            }
            let label = game.i18n.localize("MGT2.Spacecraft.Criticals."+c);
            label += ` ${severity}`;
            label += ` <i class="fas fa-xmark critDel"> </i>`;
            html += `<div class="resource flex-group-center critical ${type}" data-id="${c}"><label>${label}</label></div>`;
        }
    }
    return html;
});

Handlebars.registerHelper('criticalClass', function(sev) {
    sev = parseInt(sev);
    if (sev > 4) {
        return "criticalHigh";
    } else if (sev > 2) {
        return "criticalMedium";
    }
    return "criticalLow";
});

Handlebars.registerHelper('showSimpleSkills', function(actor) {
    if (actor && actor.system && actor.system.skills) {
        let skills = actor.system.skills;
        let html = "";

        for (let key in skills) {
            let skill = skills[key];
            const dataRoll='data-rolltype="skill" data-roll="2d6"';
            const dataSkill=`data-skill="${key}"`;

            if (skill.trained) {
                let showParent = true;
                if (skill.specialities) {
                    // Look for optional stuff.
                    let optionalList = null;
                    let optionalValue = 0;
                    if (actor.type === "package") {
                        optionalList = [];
                        for (let specKey in skill.specialities) {
                            if (skill.specialities[specKey].optional) {
                                optionalList.push(specKey);
                                // Assume optional specialisations all have the same value.
                                optionalValue = skill.specialities[specKey].value;
                            }
                        }
                        if (Object.keys(skill.specialities).length === optionalList.length) {
                            optionalList = [ "any" ];
                        }
                    }

                    if (optionalList && optionalList[0] === "any") {
                        showParent = false;
                        html += `<li>${skillLabel(skill, key).replace(/ /, "&nbsp;")}&nbsp;(${game.i18n.localize("MGT2.any")})&nbsp;${optionalValue}</li>`;
                    } else if (optionalList && optionalList.length > 0) {
                        showParent = false;
                        html += `<li>${skillLabel(skill, key).replace(/ /, "&nbsp;")}&nbsp;(`;
                        let list = "";
                        for (let specKey of optionalList) {
                            let spec = skill.specialities[specKey];
                            if (list !== "") list += ` ${game.i18n.localize("MGT2.or")} `;
                            list += skillLabel(spec, specKey);
                        }
                        html += `${list})&nbsp;${optionalValue}</li>`;
                    } else {
                        for (let specKey in skill.specialities) {
                            let spec = skill.specialities[specKey];
                            if (spec.trained || spec.value > 0) {
                                const dataSkillFqn = `data-skill-fqn="${key}.${specKey}"`;
                                showParent = false;
                                html += `<li class="rollable" ${dataRoll} ${dataSkillFqn} data-spec="${specKey}">${skillLabel(skill, key).replace(/ /, "&nbsp;")}&nbsp;(${skillLabel(spec, specKey).replace(/ /, "&nbsp;")})&nbsp;${spec.value}</li>`;
                            }
                        }
                    }
                }
                if (showParent) {
                    const dataSkillFqn=`data-skill-fqn="${key}"`;
                    html += `<li class="rollable" ${dataRoll} ${dataSkillFqn}>${skillLabel(skill, key).replace(/ /, "&nbsp;")}&nbsp;${skill.value}</li>`;
                }
            }
        }
        return "<ul class='skill-list'>" + html + "</ul>";
    } else {
        return "";
    }

});

Handlebars.registerHelper('chaStatus', function(cha) {
    if (cha) {
        if (cha.current > cha.value) {
            return "dmHigh";
        } else if (cha.current < cha.value) {
            return "dmLow";
        } else {
            return "dm";
        }
    } else {
        return "";
    }
});

Handlebars.registerHelper('showCrewInfo', function(actorShip, actorCrew) {
    let html = "";
    let roles = actorShip.system.crewed.crew[actorCrew.id];

    let bars = "";
    for (let id in roles) {
        let roleItem = actorShip.items.get(id);
        if (roleItem) {
            if (roleItem.system.role.department && roleItem.system.role.colour) {
                bars += `<div class="band band-${roleItem.system.role.colour}">&nbsp;</div>`;
            }
            html += `<div class="role-action-item"><span class="role-title">${roleItem.name}</span>`;
            html += `<div class="role-action-buttons">`;
            for (let id in roleItem.system.role.actions) {
                let action = roleItem.system.role.actions[id];
                let icon = "fa-comment";
                if (action.action === "weapon") {
                    icon = "fa-crosshairs";
                } else if (action.action === "skill") {
                    icon = "fa-dice";
                } else if (action.action === "special") {
                    icon = "fa-wand-magic-sparkles";
                }
                html += `<span class="role-action-button" data-action="roleAction" data-action-id="${id}" data-role-id="${roleItem.id}" data-crew-id="${actorCrew.id}">`;
                html += `<i class="fa-regular ${icon}"></i> ${action.title}`;
                html += `</span>`;
            }
            html += "</div></div>";
        }
    }
    if (bars) {
        html = bars + html;
    }
    if (!html) {
        html =  game.i18n.localize("MGT2.Role.NoRoleAssigned");
    }
    return html;
});

Handlebars.registerHelper('skillToLabel', function(skillName) {
    let skillId = skillName.replaceAll(/\..*/g, "");
    let specId = (skillName.indexOf(".") < 0)?null:skillName.replaceAll(/.*\./g, "");

    let skills = MGT2.getDefaultSkills();
    let label = "";
    if (skills[skillId]) {
        label = skills[skillId].label;
        if (!label) {
            label = game.i18n.localize("MGT2.Skills." + skillId);
        }
        if (specId && skills[skillId].specialities) {
            if (skills[skillId].specialities[specId]) {
                if (skills[skillId].specialities[specId].label) {
                    label += ` (skills[skillId].specialities[specId].label)`;
                } else {
                    label += ` (${game.i18n.localize("MGT2.Skills." + specId)})`;
                }
            }
        }
    } else {
        return "Unknown skill";
    }

    return label;
});

Handlebars.registerHelper('showBehaviours', function(key, behaviours) {
    // 'behaviours' is a string of space separated behaviour values.
    // Want to return <span> elements with localised names.
    let html = "";
    let list = behaviours.split(" ");
    for (let b in list) {
        if (list[b].length > 0) {
            let style = "";
            if (CONFIG.MGT2.CREATURES.behaviours[list[b]]?.group) {
                style = CONFIG.MGT2.CREATURES.behaviours[list[b]].group;
            }
            html += `<span class='behaviour-item ${style?"behaviour-style-"+style:""}' title='${game.i18n.localize("MGT2.Creature.BehaviourText." + list[b])}' data-behaviour-id='${list[b]}'>`;
            html += `${game.i18n.localize("MGT2.Creature.Behaviour." + list[b])} `;
            if (key.owner) {
                html += `<i class="fas fa-xmark behaviour-remove"> </i>`;
            }
            html += `</span>`;
        }
    }

    return html;
});

Handlebars.registerHelper('showTraits', function(key, traits) {
    // 'behaviours' is a string of space separated behaviour values. Some will have values
    // Want to return <span> elements with localised names.
    let html = "";
    let list = traits.split(",");
    for (let i in list) {
        if (list[i].length > 0) {
            let trait = list[i].trim();
            let value = null;
            if (trait.indexOf(" ") > -1) {
                value = trait.split(" ")[1].trim();
                trait = trait.split(" ")[0].trim();
            }
            let data = CONFIG.MGT2.CREATURES.traits[trait];
            if (data) {
                html += `<span class='trait-item' data-trait-id='${trait}'>`;
                if (key.owner) {
                    if (data.set) {
                        value = parseInt(value);
                        if (value > data.min) {
                            html += `<i class="fas fa-minus trait-minus"> </i>`;
                        }
                        if (value < data.max) {
                            html += `<i class="fas fa-plus trait-plus"> </i>`;
                        }
                    } else if (data.choices) {
                        value = parseInt(value);
                        if (value > 0) {
                            html += `<i class="fas fa-minus trait-minus"> </i>`;
                        }
                        if (value < data.choices.length - 1) {
                            html += `<i class="fas fa-plus trait-plus"> </i>`;
                        }
                    } else if (data.value) {
                        value = parseInt(value);
                        let min = 1, max = 21;
                        if (data.min !== undefined) min = parseInt(data.min);
                        if (data.max !== undefined) max = parseInt(data.max);
                        if (value > min) {
                            html += `<i class="fas fa-minus trait-minus"> </i>`;
                        }
                        if (value < max) {
                            html += `<i class="fas fa-plus trait-plus"> </i>`;
                        }
                    }
                }
                html += `&nbsp;${game.i18n.localize("MGT2.Creature.Trait." + trait)} `;
                if (data.choices) {
                    html += `(${game.i18n.localize("MGT2.Creature.TraitChoice."+trait+"."+data.choices[value])}) `;
                } else if (value) {
                    html += `(${(value > 0 && !data.value) ? "+" + value : value}) `;
                }
                if (key.owner) {
                    html += `&nbsp;<i class="fas fa-xmark trait-remove"> </i>`;
                } else {
                    html += "&nbsp;";
                }
                html += "</span>";
            } else {
                console.log(`WARN: Trait [${trait}] is invalid in [${traits}]`);
            }
        }
    }

    return html;
});

Handlebars.registerHelper('showWeaponRange', function(item) {
    let html = `<div class="grid grid-4col weapon-range">`;

    const range = parseInt(item.system.weapon.range);
    const shortRange = range / 4;
    const longRange = range * 2;
    const extremeRange = range * 4;
    let unit = "m";
    if (item.system.weapon.scale === "vehicle") {
        unit = "km";
    }

    html += `<div><label>Short (+1)</label><span>${shortRange}${unit}</span></div>`;
    html += `<div><label>Medium</label><span>${range}${unit}</span></div>`;
    html += `<div><label>Long (-2)</label><span>${longRange}${unit}</span></div>`;
    html += `<div><label>Extreme (-4)</label><span>${extremeRange}${unit}</span></div>`;

    html += `</div>`;

    return html;
});

Handlebars.registerHelper('showWeaponTraits', function(key, traits) {
    // 'traits' are comma separated list of weapon traits. Some may have associated values.
    console.log("showWeaponTraits: [" + traits + "]");
    let html = "";
    let list = traits.split(",");
    for (let i in list) {
        if (list[i].length > 0) {
            let trait = list[i].trim();
            let value = null;
            if (trait.indexOf(" ") > -1) {
                value = trait.split(" ")[1].trim();
                trait = trait.split(" ")[0].trim();
            }
            let data = CONFIG.MGT2.WEAPONS.traits[trait];
            if (!data) {
                trait = trait.toLowerCase();
                data = CONFIG.MGT2.WEAPONS.traits[trait];
            }
            if (data) {
                html += `<span class='pill weapon-pill' data-trait-id='${trait}' title='${game.i18n.localize("MGT2.Item.WeaponTrait.Text."+trait)}'>`;
                if (key.owner) {
                    if (data.value !== null && data.value !== undefined) {
                        value = parseInt(value);
                        if (value > parseInt(data.min)) {
                            html += `<i class="fas fa-minus trait-minus"> </i>`;
                        }
                        if (value < parseInt(data.max)) {
                            html += `<i class="fas fa-plus trait-plus"> </i>`;
                        }
                    }
                }
                html += `&nbsp;${game.i18n.localize("MGT2.Item.WeaponTrait.Label." + trait)} `;
                if (value) {
                    html += `${value} `;
                }
                if (key.owner) {
                    html += `&nbsp;<i class="fas fa-xmark trait-remove"> </i>`;
                } else {
                    html += "&nbsp;";
                }
                html += "</span>";
            } else {
                html += `<span class='pill weapon-pill error-pill' data-trait-id='${trait}' title="Unknown trait">${trait}`;
                if (value) {
                    html += ` ${value}`;
                }
                if (key.owner) {
                    html += `&nbsp;<i class="fas fa-xmark trait-remove"> </i>`;
                } else {
                    html += "&nbsp;";
                }
                html += "</span>";
                console.log(`WARN: Trait [${trait}] is invalid in [${traits}]`);
            }
        }
    }

    return html;
});

Handlebars.registerHelper('showCargoTraits', function(key, traits) {
    // 'traits' are comma separated list of cargo traits. Each has a bonus attached to it.
    let html = "";
    let list = traits.split(",");
    for (let i in list) {
        if (list[i].length > 0) {
            let trait = list[i].trim();
            let value = null;
            if (trait.indexOf(" ") > -1) {
                value = trait.split(" ")[1].trim();
                trait = trait.split(" ")[0].trim();
            }
            html += `<span class='pill cargo-pill' data-trait-id='${trait}' title='${game.i18n.localize("MGT2.Trade."+trait)}'>`;
            if (key.owner) {
                value = parseInt(value);
                if (value > -12) {
                    html += `<i class="fas fa-minus trait-minus"> </i>`;
                }
                if (value < 12) {
                    html += `<i class="fas fa-plus trait-plus"> </i>`;
                }
            }
            html += `&nbsp;${game.i18n.localize("MGT2.Trade." + trait)} `;
            if (value) {
                html += `${(value>=0)?"+":""}${value} `;
            }
            if (key.owner) {
                html += `&nbsp;<i class="fas fa-xmark trait-remove"> </i>`;
            } else {
                html += "&nbsp;";
            }
            html += "</span>";
        }
    }

    return html;
});

// Show where cargo/freight is from on the ship sheet.
Handlebars.registerHelper('showCargoMeta', function(item) {
    if (item.type === "cargo" && item.system.cargo) {

    }
    return "";
});

Handlebars.registerHelper('showVehicleFeatures', function(key, traits) {
    // 'traits' are comma separated list of vehicle traits.
    console.log("showVehicleFeatures: " + traits);
    if (!traits || traits==="") {
        return "";
    }
    const vehicle = key?.actor?.system?.vehicle;
    const type = vehicle.type;

    let html = "";
    let list = traits.split(",");
    for (let i in list) {
        if (list[i].length > 0) {
            let trait = list[i].trim();

            let legal = false;
            let required = false;
            if (CONFIG.MGT2.VEHICLES.TYPE[type]?.allowedFeatures?.includes(trait)) {
                legal = true;
            }

            html += `<span class='pill trait-pill ${legal?"":"invalid-pill"}' data-feature-id='${trait}' title='${game.i18n.localize("MGT2.Vehicle.Feature."+trait)}'>`;
            html += `&nbsp;${game.i18n.localize("MGT2.Vehicle.Feature." + trait)} `;
            if (key.owner) {
                if (!required) {
                    html += `&nbsp;<i class="fas fa-xmark" data-feature-id="${trait}" data-action="removeFeature"> </i>`;
                } else {
                    html + `&nbsp;`;
                }
            } else {
                html += "&nbsp;";
            }
            html += "</span>";
        }
    }

    return html;
});

Handlebars.registerHelper('showVehicleTraits', function(key, traits) {
    // 'traits' are comma separated list of vehicle traits.
    console.log("showVehicleTraits: " + traits);
    if (!traits || traits==="") {
        return "";
    }
    let html = "";
    let list = traits.split(",");
    for (let i in list) {
        if (list[i].length > 0) {
            let trait = list[i].trim();

            html += `<span class='pill trait-pill' title='${game.i18n.localize("MGT2.Vehicle.Trait."+trait)}'>`;
            html += `&nbsp;${game.i18n.localize("MGT2.Vehicle.Trait." + trait)} `;
            html += "</span>";
        }
    }

    return html;
});


Handlebars.registerHelper('showSpacecraftHullTraits', function(key, traits) {
    let html = "";
    let list = traits.split(" ");
    for (let i in list) {
        if (list[i].length > 0) {
            let trait = list[i].trim();
            html += `<span class='pill hull-pill' data-option-id='${trait}' title='${game.i18n.localize("MGT2.Trade."+trait)}'>`;
            html += `&nbsp;${game.i18n.localize("MGT2.Spacecraft.Hull." + trait)} `;
            if (key.owner) {
                html += `&nbsp;<i class="fas fa-xmark option-remove"> </i>`;
            } else {
                html += "&nbsp;";
            }
            html += "</span>";
        }
    }

    return html;
});

Handlebars.registerHelper('showAdvantages', function(key, traits) {
    console.log("showAdvantages: [" + traits + "]");
    let hardware = key.item.system.hardware;
    let html = "";
    let list = traits.split(",");
    let data = CONFIG.MGT2.SPACECRAFT_ADVANTAGES[hardware.system];

    for (let i in list) {
        if (list[i].length > 0) {
            let adv = list[i].trim();
            let value = null;
            if (adv.indexOf(" ") > -1) {
                value = adv.split(" ")[1].trim();
                adv = adv.split(" ")[0].trim();
            }
            let t = "adv-pill";
            let cost = 0;
            if (!data[adv]) {
                t = "error-pill"
            } else if (data[adv].cost < 1) {
                t = "disad-pill";
            }
            html += `<span class='pill advantage-pill ${t}' data-advantage-id='${adv}'>`;
            html += game.i18n.localize("MGT2.Spacecraft.Advantages." + adv);
            if (value && parseInt(value) > 1) {
                html += " x" + value;
            }
            if (key.owner) {
                html += `&nbsp;<i class="fas fa-xmark advantage-remove"> </i>`;
            } else {
                html += "&nbsp;";
            }
            html += "</span>";
        }
    }
    return html;
});

Handlebars.registerHelper('showBases', function(key, bases) {
    let html = "";
    let list = bases.split(",");
    for (let i in list) {
        if (list[i].length > 0) {
            let base = list[i].trim();
            if (MGT2.WORLD.bases[base]) {
                html += `<span class='pill world-pill' data-base-id='${base}' title='${game.i18n.localize("MGT2.WorldSheet.Bases." + base)}'>`;
                html += `&nbsp;${game.i18n.localize("MGT2.WorldSheet.Bases." + base)} `;
            } else {
                html += `<span class='pill world-pill' data-base-id='${base}'>`;
                html += `&nbsp;${base} `;
            }
            if (key.owner) {
                html += `&nbsp;<i class="fas fa-xmark base-remove"> </i>`;
            } else {
                html += "&nbsp;";
            }
            html += "</span>";
        }
    }

    return html;
});

Handlebars.registerHelper('showWorldTraits', function(key, traits, auto) {
    // 'traits' are comma separated list of cargo traits. Each has a bonus attached to it.
    let html = "";
    let list = traits.split(",");
    for (let i in list) {
        if (list[i].length > 0) {
            let trait = list[i].trim();
            if (trait.indexOf(" ") > -1) {
                trait = trait.split(" ")[0].trim();
            }
            html += `<span class='pill world-pill' data-code-id='${trait}' title='${game.i18n.localize("MGT2.Trade."+trait)}'>`;
            html += `&nbsp;${game.i18n.localize("MGT2.Trade." + trait)} `;
            if (!auto && key.owner) {
                html += `&nbsp;<i class="fas fa-xmark code-remove"> </i>`;
            } else {
                html += "&nbsp;";
            }
            html += "</span>";
        }
    }

    return html;
});

Handlebars.registerHelper('selectedWeaponId', function(actions, id) {
    if (actions && id && actions[id]) {
        return actions[id].weapon;
    } else {
        return "";
    }
});

Handlebars.registerHelper('showAttachedWeapons', function(ship, item) {
    let weapons = item.system?.hardware?.weapons;
    if (weapons) {
        let text = "";
        for (let wpnId in weapons) {
            let wpn = ship.items.get(wpnId);
            if (wpn) {
                let label = wpn.name;
                let q = weapons[wpnId].quantity;

                text += `<br/>${label}`;
                if (q > 1) {
                    text += ` x${q}`;
                }
            }
        }
        return text;
    }
    return "";
});

Handlebars.registerHelper('showSpacecraftAttacks', function(shipActor, roles) {
    let html = "";

    let weapons = [];
    for (let item of shipActor.items) {
        if (item.type === "hardware" && item.system?.hardware?.system === "weapon") {
            for (let w in item.system.hardware.weapons) {
                // If we have at least one weapon attached, add it to the list.
                weapons.push(item);
                break;
            }
        }
    }

    if (weapons.length === 0) {
        return "No weapons attached";
    }

    for (let wpnMount of weapons) {
        html += `<div class="mount"><label>${wpnMount.name}</label>`;

        for (let wpnId in wpnMount.system.hardware.weapons) {
            let wpn = shipActor.items.get(wpnId);
            html += `<span class="weapon-action-button">`;
            html += `${wpn.name}`;
            if (wpnMount.system.hardware.weapons[wpnId].quantity > 1) {
                html += ` x ${wpnMount.system.hardware.weapons[wpnId].quantity}`;
            }
            html += `</span>`;
        }

        html += `</div>`;
    }
    return html;
});

// Display information about active effects on an actor.
Handlebars.registerHelper("showEffectPill", function(actor, effect) {
    let html = "";

    let title = `${effect.name}`;
    if (effect.origin) {
        title = `${effect.sourceName}: ${effect.name}`;
    }
    for (let change of effect.changes) {
        let text = "";
        if (!effect.origin) {
            text = effect.name;
        }
        let key = change.key;
        let value = change.value;
        if (key.startsWith("system.skills.")) {
            key = key.replaceAll(/system\.skills\./g, "");
            let type = key.replaceAll(/.*\./g, "");
            let skillId = key.replaceAll(/\..*/g, "");
            let specId = null;

            let typeLabel = game.i18n.localize("MGT2.TravellerSheet.AugmentType." + type);
            if (key.indexOf(".specialities")> -1) {
                specId = key.replaceAll(/.*\.specialities\.([^.]*)\..*/g, "$1");
            }
            let skill = null;
            let skillName = null;
            if (actor.system.skills[skillId]) {
                skill = actor.system.skills[skillId];
                skillName = skillLabel(skill, skillId);
                if (specId && actor.system.skills[skillId].specialities[specId]) {
                    skill = actor.system.skills[skillId].specialities[specId];
                    skillName += ` (${skillLabel(skill, specId)})`
                }
            }
            if (text !== "") {
                text += " / ";
            }
            text += ` ${skillName} ${typeLabel} ${value}`;
        } else if (key.startsWith("system.characteristics.")) {
            key = key.replaceAll(/system\.characteristics\./g, "");
            key = key.replaceAll(/\..*/g, "");

            text += ` ${key} ${value}`;
        } else if (key.startsWith("system.modifiers.")) {
            key = key.replaceAll(/system\.modifiers\./g, "");

            if (key.startsWith("encumbrance.multiplierBonus")) {
                text += ` Encumbrance x${value}`;
            } else if (key.startsWith("encumbrance")) {
                text += `Encumbrance DM ${value}`;
            } else if (key.startsWith("guncombat")) {
                text += `Gun Combat ${value}`;
            } else if (key.startsWith("melee")) {
                text += `Melee ${value}`;
            } else if (key.startsWith("physical")) {
                text += `Physical ${value}`;
            }

        }
        let origin = fromUuidSync(effect.origin);
        let extraClasses = "";
        let remove = "";
        if (!origin) {
            extraClasses = "unlinked";
        }
        if (actor.effects.get(effect._id)) {
            // If the effect is directly on this actor, then it can be removed.
            // Otherwise it is from an item, and the item needs to be removed.
            remove = ` &nbsp;<i class="fas fa-xmark effect-remove"> </i>`;
        }
        html += `<span class="effectPill ${extraClasses}" data-effect-id="${effect._id}" title="${title}">${text}${remove}</span>`;
    }

    return html;
});

// Item block for new V2 actor sheets.
Handlebars.registerHelper("itemBlock", function(actor, item, types) {
    let html = `<li class="item-block draggable" data-item-id="${item._id}">`;
    html += `<h4>${item.name}</h4>`;
    html += `<img class="portrait" src="${item.img}"/>`;
    const system = item.system;
    switch (item.type) {
        case "weapon":
            if (system.weapon) {
                html += `<b>D:</b> ${system.weapon.damage} <b>R:</b> ${system.weapon.range}m `;
            }
            break;
        case "armour":
            break;
        default:
            break;
    }
    html += `<br/>`;
    if (parseInt(system.weight) > 0) {
        html += `${system.weight}kg `;
    }
    if (parseInt(system.cost) > 0) {
        html += `Cr${system.cost} `;
    }
    html += `<div class="item-controls">
        <a class="item-control" data-action="editItem"title="${game.i18n.localize('MGT2.EditItem')}">
            <i data-item-id="${item._id}" class="fas fa-edit"></i>
        </a>
        <a class="item-control" data-action="deleteItem" title="${game.i18n.localize('MGT2.DeleteItem')}">
            <i data-item-id="${item._id}" class="fas fa-trash"></i>
        </a>
    </div>`;
    html += `</li>`;
    return html;
});

Handlebars.registerHelper("weaponBlock", function(item, action) {
    if (!item) {
        return "";
    }
    let html = `<li class="item-block draggable" data-item-id="${item._id}" data-action="${action}">`;
    const system = item.system;
    html += `<h4>
        ${item.name}
        <img src="systems/mgt2e/icons/misc/scale-${system.weapon.scale}.svg" class="weapon-scale"/>
    </h4>`;
    let damage = system.weapon.damage;
    const destructive = hasTrait(system.weapon.traits, "destructive")?"destructive":"";
    html += `<span class="damage-dice ${destructive}">${damage}</span>`;
    switch (system.weapon.scale) {
        case "vehicle":
            html += ` / <b>Range:</b> ${system.weapon.range}km `;
            break;
        case "spacecraft":
            html += ` / ${game.i18n.localize("MGT2.Spacecraft.Range." + system.weapon.spaceRange)}`;
            break;
        default:
            html += ` / <b>Range:</b> ${system.weapon.range}m `;
            break;
    }
    html += `<br/>`;
    if (system.weapon.traits) {
        html += `<span class="weapon-traits">${printWeaponTraits(system.weapon.traits)}</span><br/>`;
    }
    if (parseInt(system.weight) > 0) {
        html += `${system.weight}kg `;
    }
    if (system.weapon.scale === "spacecraft") {
        let mount = "Fixed";
        switch (system.weapon.mount) {
            case "fixed":
                mount = "Fixed";
                break;
            case "turret1": case "turret2": case "turret3": case "turret4":
                mount = "Turret1";
                break;
            case "barbette":
                mount = "Barbette";
                break;
            case "bay.small":
                mount = "BaySmall";
                break;
            case "bay.medium":
                mount = "BayMedium";
                break;
            case "bay.large":
                mount = "BayLarge";
                break;
            case "spinal":
                mount = "Spinal";
                break;
            default:
                mount = "Fixed";
                break;
        }
        html += `${game.i18n.localize("MGT2.Item.SpaceMount." + mount)}`
    }
    html += `</li>`;
    return html;
});

Handlebars.registerHelper("weaponMountBlock", function(mount) {
    const mountItem = mount.item;
    const weaponItem = mount.weapon;
    if (!mountItem || mountItem.type !== "option" || mountItem.system.option.type !== "weapon") {
        return "";
    }

    let html = `<li class="item-block vehicle-weapon"><h4>${mountItem.name}</h4>`;
    if (weaponItem) {
        html += `<img src="systems/mgt2e/icons/misc/scale-${weaponItem.system.weapon.scale}.svg" class="weapon-scale"/>`;
    }
    html += `</h4>`;

    const mountType = mountItem.system.option.weapon.mountType;
    if (weaponItem) {
        html += `<h5>${weaponItem.name} (${game.i18n.localize("MGT2.Vehicle.MountType." + mountType)})</h5>`;

        const system = weaponItem.system;
        let damage = system.weapon.damage;
        const destructive = hasTrait(system.weapon.traits, "destructive")?"destructive":"";
        html += `<span class="damage-dice ${destructive}">${damage}</span>`;
        if (system.weapon.traits) {
            html += `<br/><span class="weapon-traits">${printWeaponTraits(system.weapon.traits)}</span>`;
        }
        html += `<br/>`;
        if (system.weapon.scale === "spacecraft") {
            html += `${game.i18n.localize("MGT2.Spacecraft.Range." + system.weapon.spaceRange)}`;
        } else {
            const shortRange = parseInt(system.weapon.range / 4);
            const longRange = parseInt(system.weapon.range * 2);
            const extremeRange = parseInt(system.weapon.range * 4);
            const unit = (system.weapon.scale === "vehicle")?"km":"m";
            html += `<table><tr><th>${game.i18n.localize("MGT2.Attack.short")} (+1)</th><th>${game.i18n.localize("MGT2.Attack.medium")}</th><th>${game.i18n.localize("MGT2.Attack.long")} (-2)</th><th>${game.i18n.localize("MGT2.Attack.extreme")} (-4)</th></tr>`;
            html += `<tr><td>${shortRange}${unit}</td><td>${system.weapon.range}${unit}</td><td>${longRange}${unit}</td><td>${extremeRange}${unit}</td></tr>`;
            html += "</table>";
        }

    } else {
        html += `<h5>${game.i18n.localize("MGT2.Vehicle.MountType." + mountType)}</h5>`;
        html += `No weapon attached`;
    }
    html += `</li>`;
    return html;
});


Handlebars.registerHelper("itemName", function (item) {
    let html = `<li class="item-name">`;
   html += item.name;
   html += `</li>`;
   return html;
});

/* -------------------------------------------- */
/*  Ready Hook                                  */
/* -------------------------------------------- */

Hooks.once("ready", async function() {
    if (game.user.isGM) {
        let currentVersion = game.system.version;
        let lastVersion = game.settings.get("mgt2e", "lastVersionReported");

        if (foundry.utils.isNewerVersion(currentVersion, lastVersion)) {
            let text = "";
            let d = await fromUuid("Compendium.mgt2e.traveller-docs.JournalEntry.83nkkP7aeGF22kG6.JournalEntryPage.mXeFfBZITS7IkfPU");
            if (d && d.text && d.text.content) {
                text = `<h1>MgT2e ${currentVersion}</h1>${d.text.content}`;
            } else {
                text = `<p>Upgraded to ${currentVersion}`;
            }
            let chatData = {
                content: text
            };
            ChatMessage.create(chatData, {});
            game.settings.set("mgt2e", "lastVersionReported", currentVersion);
        }
    }
});

