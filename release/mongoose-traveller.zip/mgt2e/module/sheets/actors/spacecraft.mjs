import {MgT2ActorSheet} from "../actor-sheet.mjs";


export class MgT2SpacecraftActorSheet extends MgT2ActorSheet {
    // Not yet used. Probably move this to V2?
}
